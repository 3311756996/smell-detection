java -Dawt.useSystemAAFontSettings=on -jar aDoctor-1.0.jar
