package testtttttt;

import com.daap.model.LegacyClass;
import com.daap.model.LegacySystem;
import com.daap.parse.MyDpvdVisitor;
import com.daap.util.DirExplorer;
import com.github.javaparser.JavaParser;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.body.VariableDeclarator;
import com.github.javaparser.ast.expr.MethodCallExpr;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;

import java.io.File;
import java.io.IOException;
import java.sql.SQLOutput;
import java.util.*;

/**
 * @author shkstart
 * @create 2022-01-14-22:04
 */
public class FeatureEnvy {



    public static void main(String[] args) {
        File projectDir = new File("D:\\IdeaProjects\\ImageViewer\\src\\testFeatureEnvy");
        List<ClassOrInterfaceDeclaration> classDeclaration = new ArrayList<ClassOrInterfaceDeclaration>();  //存了类
        List<String> methodName = new ArrayList<String>();  //存了方法名
        List<String> valueName = new ArrayList<String>();  //存了变量名
        List<String> valueCallName = new ArrayList<String>(); //存整个类中 使用过了的变量的名字

        Map<Node,Node> variableMap1 = new HashMap<Node,Node>(); //存了全部的变量名 和 变量类型  是Node类型

        Map<String,String> variableMap = new HashMap<String,String>();
        Map<Node,Node> variableMapTrue = new HashMap<Node,Node>(); //存了筛选之后的变量名 和 变量类型
        Map<Node,Node> variableMapFinal = new HashMap<Node,Node>();
        List<MethodDeclaration> methodNode = new ArrayList<MethodDeclaration>(); //存了方法的MethodDeclaration类型的形式，要用它的contains方法判断变量在哪个方法中

        MyDpvdVisitor.listClasses(projectDir);

        for (LegacyClass legacyClass : LegacySystem.getInstance().getAllClasses()) {
            classDeclaration.add(legacyClass.getClassOrInterfaceDeclaration());
            for(MethodCallExpr methodCallExpr : legacyClass.getMethodCallExprs()){
//                System.out.println(methodCallExpr);
                String[] s = methodCallExpr.toString().split("\\.");
                valueCallName.add(s[0]);
            }
            for(MethodDeclaration methodDeclaration : legacyClass.getMethodDeclarations()){
                methodNode.add(methodDeclaration);
                methodName.add(methodDeclaration.getName().toString());
            }
            for(VariableDeclarator variableDeclarator : legacyClass.getVariableDeclarators()){
                variableMap1.put(variableDeclarator.getChildNodes().get(1),variableDeclarator.getChildNodes().get(0));
            }
        }

//        new DirExplorer((level, path, file) -> path.endsWith(".java"), (level, path, file) -> {
//            System.out.println(path);
//            System.out.println("===============");
//            try {
//
//                new VoidVisitorAdapter<Object>() {
//
//                    @Override
//                    public void visit(MethodCallExpr n, Object arg) {   //所有的变量调用方法
//                        super.visit(n, arg);
//                        String[] s = n.toString().split("\\.");  ///@@@@@
//                        valueCallName.add(s[0]);
////                        System.out.println(n.);
////                        System.out.println(s[0]); //@@@@
//                    }
//
//                    @Override
//                    public void visit(MethodDeclaration n, Object arg) {
//                        super.visit(n, arg);
//                        methodNode.add(n);
//                        methodName.add(n.getName().toString());
//                    }
//
//                    @Override
//                    public void visit(VariableDeclarator n, Object arg) {
//                        super.visit(n, arg);
////                        variableList[i++] = n.getChildNodes();
////                        variableMap.put(n.getName().toString(),n.getType().toString());
////                        System.out.println(n.getName() + "====" +n.getType());
//                        variableMap1.put(n.getChildNodes().get(1),n.getChildNodes().get(0));
//                    }
//
//
//
//                }.visit(JavaParser.parse(file), null);
//                System.out.println(); // empty line
//            } catch (IOException e) {
//                new RuntimeException(e);
//            }
//        }).explore(projectDir);

        Set keySet = variableMap1.keySet();
        for(Object key : keySet){
            Node value = variableMap1.get(key);
//            System.out.println(value);
            for(int i = 0; i < classDeclaration.size(); i++) {
                if(value.toString().equals(classDeclaration.get(i).getName().toString())){  //去掉并不是已有自己的类的类型的变量
//                    System.out.println(value);
                    valueName.add(value.toString());  //真正需要用的变量名
                    if(key instanceof Node && value instanceof Node){
                        variableMapTrue.put((Node) key,value); //真正需要用的变量名-变量类型
                    }
                }
            }
        }

        //将有用的变量名，同使用了的变量进行数量统计
        Set keySetTure = variableMapTrue.keySet();
        int total2;
        for(Object key : keySetTure) {
            total2 = 0;
            for(int i = 0; i < valueCallName.size(); i++){
                if(valueCallName.get(i).toString().equals(key.toString())){
                    total2++;
                }
            }
            System.out.println(total2+"==="+key);
            if(total2 >= 3){
                variableMapFinal.put((Node) key,variableMapTrue.get(key));
            }

        }
//        System.out.println(variableMapFinal);
        Set keySetFinal = variableMapFinal.keySet();
        System.out.println(keySetFinal);
        System.out.println();
        System.out.println("构成Feature Envy的有:");
        for(Object key : keySetFinal) {
            for (int i = 0; i < methodNode.size(); i++) {
//                System.out.println(methodNode.get(i));
                if (methodNode.get(i).toString().contains(key.toString()) ) { //这里出了问题，没有让变量和方法正确匹配
////                    System.out.println(methodNode.get(i));
                    for(int j = 0; j < classDeclaration.size(); j++){
                        if(!classDeclaration.get(j).getMethodsByName(methodNode.get(i).getName().toString()).isEmpty()){
//                            System.out.println(classDeclaration.get(j).getName()+": "+methodNode.get(i).getName()+"->"+variableMapTrue.get(key));
                            System.out.println(classDeclaration.get(j).getNameAsString());
                        }
                    }
                }

            }
        }

//
//            System.out.println(key);
//            if(methodNode.get(0).containsWithin((Node) key)) {
//                System.out.println(key);  //方法中存在这个变量
//            }



//
//    String s = "zhuwei";
//        System.out.println(s.contains("hi"));
    }

}
