package testtttttt;

import com.daap.model.DetectedInstance;
import com.daap.ui.ASD;
import com.daap.util.Constants;
import com.github.javaparser.JavaParser;

/**
 * @author shkstart
 * @create 2021-10-15-11:43
 */
public class Test {

    public void x(){
        System.out.println("just soso");
    }

    public static void y(){
        System.out.println("i don't know");
    }

    public static void main(String[] args) {
//        int x = Integer.parseInt(args[0]);
//        System.out.println(" sign (x) is : " + sign(x));
//        JavaParser.parse()
//        String a = "abc def  ghi";
//        String[] b = a.split(" ");
//        for(int i = 0; i < b.length;i++) {
//            for(int j = 0; j < b[i].length(); j++){
//                b[i].charAt()
//            }
//        }

    }

    private static int sign(int x){
        if(x > 0){
            return 1;
        }else if(x < 0){
            return -1;
        }else return 0;
    }
//     if(methodNode.get(i).toString().contains(key.toString())){
//        //                if (methodNode.get(i).toString().contains(key.toString()) ) { //这里出了问题，没有让变量和方法正确匹配
//        ////                    System.out.println(methodNode.get(i));
//        for(int j = 0; j < classDeclaration.size(); j++){
//            if(!(classDeclaration.get(j).getMethodsByName(methodNode.get(i).getName().toString()).isEmpty())){
//                System.out.println(classDeclaration.get(j).getName()+": "+methodNode.get(i).getName()+"->"+variableMapTrue.get(key)+"---"+key);
//                //                            System.out.println(classDeclaration.get(j).get);
//                total++;
//                ASD.writeMessage("Class Name: " + classDeclaration.get(j).getName()+"  :\nMethod name: "
//                        + methodNode.get(i).getName() +" -> Class: " + variableMapTrue.get(key) + "\n"
//                );
//                flag = true;
//                for(int k = 0; k < legacyClassList.size(); k++){
//                    if(legacyClassList.get(k).getClassOrInterfaceDeclaration().equals(classDeclaration.get(j))){
//                        Constants.setHmap(legacyClassList.get(k).getPath(),Constants.A_FEATURE_ENVY);
//                        System.out.println(legacyClassList.get(k).getPath());
//                        boolean exists = true;
//                        for (DetectedInstance detectedInstance: detectedInstances){
//                            if (detectedInstance.getName().equals(legacyClassList.get(k).getName())){
//                                detectedInstance.increment();
//                                exists = false;
//                                break;
//                            }
//                        }
//                        if (exists){
//                            detectedInstances.add(new DetectedInstance(legacyClassList.get(k).getName(), legacyClassList.get(k).getPath(), 1));
//                        }
//                        break;
//                    }
//                }
//
//            }
//            //                        if(flag){
//            //                            break;
//            //                        }
//        }
//    }
//                    if(flag){
//        System.out.println("}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}");
//        break; //保证了只使用一次变量去查询FE，否则只要方法里包括这个满足FE的，都会被列为FE
//    }
//}
}
