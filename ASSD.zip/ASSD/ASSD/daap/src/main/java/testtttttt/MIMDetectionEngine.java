//package testtttttt;
//
//import com.daap.model.LegacyClass;
//import com.daap.model.LegacySystem;
//import com.github.javaparser.ast.NodeList;
//import com.github.javaparser.ast.body.FieldDeclaration;
//import com.github.javaparser.ast.body.MethodDeclaration;
//import com.github.javaparser.ast.stmt.Statement;
//import com.tj.model.LegacyClass;
//import com.tj.model.LegacySystem;
//import com.tj.test.TestMIM;
//import com.tj.util.CreateFile;
//
//import java.util.ArrayList;
//import java.util.List;
//import java.util.regex.Matcher;
//import java.util.regex.Pattern;
//
//import static com.tj.util.CreateFile.createMyMIMData;
//
///**
// * Created by Azhar on 9/21/2017.
// */
//public class MIMDetectionEngine {
//    private static   int total ;
//    private static ArrayList<MethodDeclaration> isMimList=new ArrayList<>();
//    private static ArrayList<MethodDeclaration> notMimList=new ArrayList<>();
//    private static int totalTest,totalMethod;
//
//    public MIMDetectionEngine() {
//    }
//    private static void called_Filter1(MethodDeclaration methodDeclaration,ArrayList<MethodDeclaration> nonMIMsmellyArrayList,ArrayList<MethodDeclaration> isMIMsmellyArrayList){
//
//        if(nonMIMsmellyArrayList.size()==0||isMIMsmellyArrayList.size()==0)
//            return;
//        int size=nonMIMsmellyArrayList.size();
//        for (int i = 0; i < nonMIMsmellyArrayList.size(); i++) {
//            for (Statement statement: methodDeclaration.getBody().get().getStatements()) {
////                System.out.println("size=="+size+"==state"+methodDeclaration.getBody().get().getStatements().size());
//                //遍历non，这个method内有没有调用non方法
//                if(statement.toString().contains(nonMIMsmellyArrayList.get(i).getName().toString())){
////                    System.out.println(statement.toString()+"====="+nonMIMsmellyArrayList.get(i).getName().toString());
//                    nonMIMsmellyArrayList.add(methodDeclaration);
////                    size++;不能加了
//                    isMIMsmellyArrayList.remove(methodDeclaration);
//                    //这是一个从mim中移出来的method所以需要看看这个方法是不是在mim中有被调用
//                    called_Filter2(nonMIMsmellyArrayList,isMIMsmellyArrayList ,methodDeclaration);
//
//                    return;
//                }
//
//            }
//        }
//
//    }
//
//    private static void called_Filter2(ArrayList<MethodDeclaration> nonMIMSmellyArrayList,ArrayList<MethodDeclaration> isMIMsmellyArrayList, MethodDeclaration methodDeclaration) {
//        if(nonMIMSmellyArrayList.size()<=0||isMIMsmellyArrayList.size()<=0){
//            return;
//        }
//        //判断每一个是MIM的方法是否调用当前noMIM
//        for (int i = 0; i < isMIMsmellyArrayList.size(); i++) {
//            for (Statement statement:isMIMsmellyArrayList.get(i).getBody().get().getStatements()) {
//                if(statement.toString().contains(methodDeclaration.getNameAsString())){
//                    //调用了则转移到noMIM
//                    MethodDeclaration method_1=isMIMsmellyArrayList.get(i);
//                    nonMIMSmellyArrayList.add(method_1);
//
//                    isMIMsmellyArrayList.remove(method_1);
//                    i--;//移走了，则后一个填补到当前这个来了，arraylist变小了,否则会跳过一个
//                    called_Filter2(nonMIMSmellyArrayList,isMIMsmellyArrayList,method_1);
//                    //递归调用继续寻找这个转换为nonMIM的方法是否有被其他MIM方法调用
//                    break;
//                }
//            }
//        }
//    }
//
//    private static boolean intersection(List<FieldDeclaration> allFields, NodeList<Statement> fieldsAccessList) {
//
//        for (FieldDeclaration fieldDeclaration :allFields) {
//            for (Statement statement : fieldsAccessList) {
//                if (statement.toString().contains(fieldDeclaration.getVariable(0).getNameAsString())) {
////                    System.out.println(statement.toString()+"+++"+fieldDeclaration.getVariable(0).getNameAsString());
//                    return true;
//                }
//            }
//        }
//        return false;
//    }
//
//    private static List<FieldDeclaration> getAllFields(LegacyClass legacyClass){
//        List<FieldDeclaration> list=new ArrayList<>();
//        //获取本类的属性
//        list.addAll(legacyClass.getFieldDeclarations());
////        System.out.println(list);
//        if(legacyClass.getClassOrInterfaceDeclaration().getExtendedTypes().size()!=0) {
////            System.out.println(legacyClass.getName() + "**parentClass**:\n" + legacyClass.getClassOrInterfaceDeclaration().getExtendedTypes().get(0).toString());
//            for (LegacyClass lc : LegacySystem.getInstance().getAllClasses()) {
//                if (lc.getName().equals(legacyClass.getClassOrInterfaceDeclaration().getExtendedTypes().get(0).toString())) {
//                    //得到了父类，看看父类还有没有父类
//                    list.addAll(getAllFields(lc));
//                    return list;
//                }
//            }
//        }
//        return list;
//    }
//
//    public static void detect() {
//        total=0;
//        totalTest=0;
//        totalMethod=0;
//        System.out.println("======================STARTED-------------------");
//
//
//        for (LegacyClass legacyClass : LegacySystem.getInstance().getAllClasses()) {
//            createMyMIMData("\n<tr>");
//            createMyMIMData("\n<td>"+legacyClass.getPath()+"</td>");
//            isMimList.clear();
//            notMimList.clear();
//            for (MethodDeclaration methodDeclaration : legacyClass.getMethodDeclarations()) {totalMethod++;
//                if (methodDeclaration.isStatic()||isNullMethod2(methodDeclaration)||isOverride2(methodDeclaration)) {
//                    notMimList.add(methodDeclaration);
//                    continue;
//                }
//                NodeList<Statement> fieldsAccessList = getFieldsAccessList(methodDeclaration);
//
//                if(!intersection(getAllFields(legacyClass),fieldsAccessList)){
//                    total++;
//                    isMimList.add(methodDeclaration);
//                    called_Filter1(methodDeclaration,notMimList,isMimList);
//                    continue;
//                }
//                notMimList.add(methodDeclaration);
//            }
//            totalTest+=isMimList.size();
//
//            createMyMIMData("\n<td>"+isMimList.size()+"</td>");
//            createMyMIMData("\n</tr>");
//        }
//        System.out.println("total: " + total+"===="+totalTest);
//        createMyMIMData("\n</table>");
//        createMyMIMData("\n## appTotal:"+totalTest+"\n");
//        createMyMIMData("\n## methodTotal:"+totalMethod+"\n");
//        CreateFile.createMyMIMData_2("<tr>"+
//                "\n<td>"+TestMIM.projects[TestMIM.i]+"</td>"
//                +"\n<td>"+totalTest+"</td>"
//                +"\n</tr>");
//        System.out.println("======================FINISHED-------------------");
//
//
//    }
//
//    private static boolean isNullMethod2(MethodDeclaration methodDeclaration) {
//        try {
//            if (methodDeclaration.getBody().get().getStatements().size()==0){
//                return true;
//            }else {
//                return false;
//            }
//        }catch (Exception e){
//            return true;
//        }
//    }
//
//    private static boolean isOverride2(MethodDeclaration methodDeclaration) {
//        for (int i = 0; i < methodDeclaration.getAnnotations().size(); i++) {
//            if (methodDeclaration.getAnnotations().get(i).toString().contains("@Override")){
//                return  true;
//            }
//        }
//        return false;
//    }
//
//    private static  boolean isNullMethod(MethodDeclaration methodDeclaration){
//        String regex="\\w";
//        try {
//            StringBuffer stringBuffer = new StringBuffer(methodDeclaration.clone().toString());
//            stringBuffer = new StringBuffer(stringBuffer.substring(stringBuffer.indexOf("{") + 1, stringBuffer.lastIndexOf("}")));
//            Pattern p = Pattern.compile(regex);
//            Matcher m = p.matcher(stringBuffer.toString());
//            if(m.find()&&stringBuffer.toString().indexOf(";")!=-1){
//                return false;
//            }else {
//                return true;
//            }
//        }catch (Exception e){
//            return true;
//        }
//    }
//    private static boolean isOverride(MethodDeclaration methodDeclaration){
//        String regex="@Override";
//        try {
//            StringBuffer stringBuffer = new StringBuffer(methodDeclaration.clone().toString());
//            stringBuffer = new StringBuffer(stringBuffer.substring(0,stringBuffer.indexOf("{") -1));
//
//            if(stringBuffer.toString().indexOf(regex)!=-1){
//                return true;
//            }else {
//                return false;
//            }
//        }catch (Exception e){
//            return false;
//        }
//    }
//    private static   NodeList<Statement> getFieldsAccessList(MethodDeclaration methodDeclaration) {
//
//        NodeList<Statement> statements = new NodeList<>();
//
//        try {
//            statements = methodDeclaration.getBody().get().getStatements();
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//
//        return statements;
//
//    }
//
//}
