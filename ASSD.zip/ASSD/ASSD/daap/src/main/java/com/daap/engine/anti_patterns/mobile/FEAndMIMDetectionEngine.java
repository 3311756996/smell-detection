package com.daap.engine.anti_patterns.mobile;

import com.daap.model.DetectedInstance;
import com.daap.model.LegacyClass;
import com.daap.model.LegacySystem;
import com.daap.ui.ASD;
import com.daap.util.Constants;
import com.daap.util.Helper;
import com.daap.util.ResultDocument;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.NodeList;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.FieldDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.body.VariableDeclarator;
import com.github.javaparser.ast.expr.MethodCallExpr;
import com.github.javaparser.ast.stmt.Statement;

import java.util.*;

/**
 * @author shkstart
 * @create 2022-02-09-14:21
 */
public class FEAndMIMDetectionEngine {
//    private static final int DIT = 6;
    private static int total = 0;
//    private static final String fileName = "Feture Envy And Member Ignoring Method";

    public static void detect() {
//        XWPFDocument doc;
//        XWPFTable table;
//        doc = new XWPFDocument();
//        table = doc.createTable();
//        table.getRow(0).getCell(0).setText("Sr. No");
//        table.getRow(0).createCell().setText("Class");
////        table.getRow(0).createCell().setText("Method");
//        table.getRow(0).createCell().setText("Path");


//        ASD.clearConsole();
        ASD.writeMessage("M I M And F E:\n");
        ResultDocument resultDocument = new ResultDocument(Constants.A_FE_MIM);
        ArrayList<DetectedInstance> detectedInstances = new ArrayList<>();
        total = 0;  // check it.

        List<ClassOrInterfaceDeclaration> classList = new ArrayList<ClassOrInterfaceDeclaration>();

        System.out.println("======================STARTED-------------------");


        List<ClassOrInterfaceDeclaration> classDeclaration = new ArrayList<ClassOrInterfaceDeclaration>();  //������
        List<String> methodName = new ArrayList<String>();  //���˷�����
        List<String> valueName = new ArrayList<String>();  //���˱�����
        List<String> valueCallName = new ArrayList<String>(); //���������� ʹ�ù��˵ı���������

        Map<Node,Node> variableMap1 = new HashMap<Node,Node>(); //����ȫ���ı����� �� ��������  ��Node����

        Map<String,String> variableMap = new HashMap<String,String>();
        Map<Node,Node> variableMapTrue = new HashMap<Node,Node>(); //����ɸѡ֮��ı����� �� ��������
        Map<Node,Node> variableMapFinal = new HashMap<Node,Node>();
        List<MethodDeclaration> methodNode = new ArrayList<MethodDeclaration>(); //���˷�����MethodDeclaration���͵���ʽ��Ҫ������contains�����жϱ������ĸ�������
//        List<String> v1 = new ArrayList<>();
//        List<String> v2 = new ArrayList<>();

//        MyDpvdVisitor.listClasses(projectDir);

        for (LegacyClass legacyClass : LegacySystem.getInstance().getAllClasses()) {
            classDeclaration.add(legacyClass.getClassOrInterfaceDeclaration());  //��ȡ����Ϣ
            for(MethodCallExpr methodCallExpr : legacyClass.getMethodCallExprs()){
                String[] s = methodCallExpr.toString().split("\\.");
                valueCallName.add(s[0]);   //��ȡ����ʹ�ù��ı���������.������
            }
            for(MethodDeclaration methodDeclaration : legacyClass.getMethodDeclarations()){
                methodNode.add(methodDeclaration);
                methodName.add(methodDeclaration.getName().toString());  //����������
            }
            for(VariableDeclarator variableDeclarator : legacyClass.getVariableDeclarators()){
                variableMap1.put(variableDeclarator.getChildNodes().get(1),variableDeclarator.getChildNodes().get(0));
            }
        }

        Set keySet = variableMap1.keySet();
        for(Object key : keySet){
            Node value = variableMap1.get(key);
//            System.out.println(value);
            for(int i = 0; i < classDeclaration.size(); i++) {
                if(value.toString().equals(classDeclaration.get(i).getName().toString())){  //ȥ�������������Լ���������͵ı���
//                    System.out.println(value);
                    valueName.add(value.toString());  //������Ҫ�õı�����
                    if(key instanceof Node && value instanceof Node){
                        variableMapTrue.put((Node) key,value); //������Ҫ�õı�����-��������
                    }
                }
            }
        }

        //�����õı�������ͬʹ���˵ı�����������ͳ��
        Set keySetTure = variableMapTrue.keySet();
        int total2;
        for(Object key : keySetTure) {
            total2 = 0;
            for(int i = 0; i < valueCallName.size(); i++){
                if(valueCallName.get(i).toString().equals(key.toString())){
                    total2++;
                }
            }
            System.out.println(total2+"==="+key);
            if(total2 >= 5){
                variableMapFinal.put((Node) key,variableMapTrue.get(key));
            }

        }
//        System.out.println(variableMapFinal);
        Set keySetFinal = variableMapFinal.keySet();
        System.out.println(keySetFinal);
        System.out.println();
        System.out.println("����Feature Envy����:");
        for(Object key : keySetFinal) {
            for (int i = 0; i < methodNode.size(); i++) {
//                System.out.println(methodNode.get(i));
                if (methodNode.get(i).toString().contains(key.toString()) ) { //����������⣬û���ñ����ͷ�����ȷƥ��
////                    System.out.println(methodNode.get(i));
                    for(int j = 0; j < classDeclaration.size(); j++){
                        if(!classDeclaration.get(j).getMethodsByName(methodNode.get(i).getName().toString()).isEmpty()){
                            System.out.println(classDeclaration.get(j).getName()+": "+methodNode.get(i).getName()+"->"+variableMapTrue.get(key));
//                            methodList.add()
                            classList.add(classDeclaration.get(j));
                        }
                    }
                }

            }
        }
        List<LegacyClass> legacyList = new ArrayList<>();

        for (LegacyClass legacyClass : LegacySystem.getInstance().getAllClasses()) {
            for (int i = 0; i < classList.size(); i++) {
                if (legacyClass.getName().equals(classList.get(i).getNameAsString())) {
                    legacyList.add(legacyClass);
                }
            }
        }
//-----------------------------------------------------------------
        for(int i = 0; i < legacyList.size(); i++){
            System.out.println("-------------------FE"+legacyList.get(i).getName());
            LegacyClass legacyClass = legacyList.get(i);
            for (MethodDeclaration methodDeclaration : legacyClass.getMethodDeclarations()) {


                if (methodDeclaration.isStatic()) {
                    break;
                }
                NodeList<Statement> fieldsAccessList = getFieldsAccessList(methodDeclaration);

//                System.out.println("fieldsAccessList size: "+fieldsAccessList.size());
                boolean contains = false;
                outer:
                for (FieldDeclaration fieldDeclaration : legacyClass.getFieldDeclarations()) {  //��ȡ���Ա����
//                    System.out.println("fieldDeclaration: " +fieldDeclaration.getVariable(0).getNameAsString());
                    inner:
                    for (Statement statement : fieldsAccessList) {
                        if (statement.toString().contains(fieldDeclaration.getVariable(0).getNameAsString())) {
                            contains = true;
//                            System.out.println("found ");
                            break outer;
                        }
                    }
//                    if (fieldsAccessList.contains(fieldDeclaration.getVariable(0).getNameAsString())) {
//                        contains = true;
//                        System.out.println("found ");
//                        break;
//                    }
                }

                if (!contains) {

                    total++;
//                    ASD.writeMessage("Class: " + legacyClass.getName());
                    ASD.writeMessage("Class Name: " + legacyClass.getName()+""
                            + "\nPath: " + legacyClass.getPath() + "\n"
                    );
//                    ASD.writeMessage("Class Name: " + legacyClass.getName()+"  zhuwei niu"
//                            + "\nPath: " + legacyClass.getPath() + "\n"
//                    );

//                    Constants.setHmap(legacyClass.getName(),Constants.A_MEMBER_IGNORING_METHOD);
//                    Helper.writeDoc(table, legacyClass, total);
                    Constants.setHmap(legacyClass.getPath(),Constants.A_FE_MIM);
                    boolean exists = true;
                    for (DetectedInstance detectedInstance: detectedInstances){
                        if (detectedInstance.getName().equals(legacyClass.getName())){
                            detectedInstance.increment();
                            exists = false;
                            break;
                        }
                    }
                    if (exists){
                        detectedInstances.add(new DetectedInstance(legacyClass.getName(), legacyClass.getPath(), 1));
                    }
                    System.out.println("legacyClass: " + legacyClass.getName() + " methodDeclaration: " + methodDeclaration.getNameAsString());
                    break;
                }
            }


//            for (ObjectCreationExpr objectCreationExpr : legacyClass.getObjectCreationExprs()) {
//                System.out.println("legacyClass: "+legacyClass.getName()+" objectCreationExpr: "+objectCreationExpr.toString());
//            }
        }
        System.out.println("total:-------------------------FE&MIM   " + total);
        ASD.writeMessage("Total: " + total);
        ASD.detectionDone();
//        Helper.writeFile(doc, "MemberIgnoringMethod");
        System.out.println("======================FINISHED-------------------");


        int srNo = 1;
        for (DetectedInstance detectedInstance : detectedInstances) {
            Helper.writeDoc(resultDocument, detectedInstance, srNo++);
        }
        Helper.writeFile(resultDocument);
//        dsfdsf

    }


    private static NodeList<Statement> getFieldsAccessList(MethodDeclaration methodDeclaration) {

//        System.out.println(methodDeclaration.getBody().get().getStatements().toString());
//        System.out.println(methodDeclaration.getChildNodes().toString());

        NodeList<Statement> statements = new NodeList<>();

        try {
            statements = methodDeclaration.getBody().get().getStatements();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return statements;  //���ط���������

    }

//    private static  ArrayList<String> getFieldsAccessList(MethodDeclaration methodDeclaration){
//
//        ArrayList<String> result = new ArrayList<>();
//        methodDeclaration.accept(new VoidVisitorAdapter<Object>() {
//            @Override
//            public void visit(final FieldAccessExpr fieldAccessExpr, final Object arg) {
//                super.visit(fieldAccessExpr, arg);
//
//                result.add(fieldAccessExpr.getNameAsString());
//            }
//        }, null);
//
//        return result;
//    }
}

