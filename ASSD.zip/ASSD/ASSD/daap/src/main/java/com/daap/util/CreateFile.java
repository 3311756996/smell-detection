package com.daap.util;

import com.daap.model.LegacyClass;
import com.daap.model.LegacySystem;
import com.daap.ui.ASD;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

/**
 * @author ZHUWEI
 * @Description
 * @create 2022-04-12-11:31
 */
public class CreateFile {
    /**
     * @param context  ��������
     * @param smell ζ������
     * @param filename �ļ���
     * @param isBad  �Ƿ�Ϊ��ζ��
     * @throws Exception
     */
    public static void createFile(String context,String smell,String filename, boolean isBad) throws Exception{
        String s= ASD.projectSrcFolder;
//        System.out.println(ASD.projectSrcFolder + " (((((((((((((((((((((((((((((((((((((((((((((==============");
        String DRIVE=s.substring(0,2);
        String[] projectFolder = s.split("\\\\");
        String folderPath = DRIVE + "\\AndroidApp"+"\\"+projectFolder[projectFolder.length - 1];
        if(isBad){  //������
            File file = new File(folderPath+"\\"+smell);
            System.out.println(file.getAbsolutePath() + "(((((((((((((((((((((((((((((((((((((((((((((((((");
            if (!file.exists()) {
                file.mkdirs();
            }
            try {
                String filepath = folderPath+"\\"+smell+ "\\" + filename  + ".java";
                BufferedWriter bw = new BufferedWriter(new FileWriter(filepath));
//                System.out.println("-=-=-=-=-=-=-=filepath:" + filepath + "-=-=-=-=-=-=-=-=-=-=-=-=");
                bw.write(context);
                bw.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }else{     //������
            File file = new File(folderPath+"\\NOT_"+smell);
            if (!file.exists()) {
                file.mkdirs();
            }
            try {
                String filepath = folderPath+"\\Not_"+smell + "\\" +filename + ".java";
                BufferedWriter bw = new BufferedWriter(new FileWriter(filepath));
//                System.out.println("-=-=-=-=-=-=-=filepath:" + filepath + "-=-=-=-=-=-=-=-=-=-=-=-=");
                bw.write(context);
                bw.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }


//    private static boolean isSFLAndMIM = false;
//    private static int ISSFLMIM = 0;
//    private static int NOTSFLMIM = 0;
//    public static String smellTwo = "SFLandMIM";

    private static boolean isTWO = false;
    private static int ISTWO = 0;
    private static int NOTTWO = 0;
    private static String smellTwo = "";

    public static void reset(){
        isTWO = false;
        ISTWO = 0;
        NOTTWO = 0;
        smellTwo = "";
    }

    /**
     * ���ɸ�����  ����Ϊ��λ
     *  ��һ�� ����ζ �� �� ������ϵ  ��ֵ�� ----  �� ���� ����Ӧ������Ķ���������MIM�ķ����壬����SFL��ѭ���壬����ֻ����MIM��ֻ����SFL��
     *  Map  (string-(string-string))
     *        ��ζ�� - ������-��ζ�壩
     *  �ڶ�����Ϊmap.put����ͬ��key�Ḳ�ǣ�����valueֻ����һ��
     *  StringBuilder  ��ͬһ�������ζ��append��һ��Ȼ����toString �Ž�map
     */

    public static void createNothing(){
        //û�й��� ���ڸ�����,  nothing
        isTWO = false;
        for(int i = 0; i < Constants.Nothing.size(); i++){
            try {
                CreateFile.createFile(Constants.Nothing.get(i),smellTwo,NOTTWO+++"",isTWO);
            } catch (Exception exception) {
                exception.printStackTrace();
            }
        }

    }


    public static void createNo(String smellFirst, String smellSencond, String twoSmellName){

//        smellTwo += twoSmellName;
        isTWO = false;

        HashMap<String, HashMap<String, String>> noMap = Constants.NO;
        HashMap<String, String> first = null;
        if(noMap.containsKey(smellFirst)){
            first = noMap.get(smellFirst);
        }
        HashMap<String, String> second = null;
        if(noMap.containsKey(smellSencond)){
            second = noMap.get(smellSencond);
        }


        for (LegacyClass legacyClass : LegacySystem.getInstance().getAllClasses()) {

            String firstSmellBody = null;
            if(first != null)
                firstSmellBody = first.get(legacyClass.getName());

            String secondSmellBody = null;
            if(second != null)
                secondSmellBody = second.get(legacyClass.getName());

            StringBuilder sb = new StringBuilder();

            if(firstSmellBody != null){
                sb.append(firstSmellBody);
                sb.append("\n");
            }
            if(secondSmellBody != null){
                sb.append(secondSmellBody);
            }


            try {
                CreateFile.createFile(sb.toString(),smellTwo,""+NOTTWO++,isTWO);
            } catch (Exception exception) {
                exception.printStackTrace();
            }


        }



    }

    /**
     *  ����������ζ���棬����Ϊ��λ
     * @param smellFirst : ����Constans��ĳ�����ζ��
     * @param smellSencond������Constans��ĳ�����ζ��
     * @param twoSmellName����ζ������д��ʽ����and���ӣ����磺SFLandMIM
     *
     */
    public static void createTwoSmell2(String smellFirst, String smellSencond, String twoSmellName){



        smellTwo += twoSmellName;
        HashMap<String, HashMap<String,Integer>> map = Constants.HMAP;
        Set<Map.Entry<String, HashMap<String, Integer>>> entries = map.entrySet();
        for(Map.Entry<String, HashMap<String, Integer>> entry:entries) {

            String name = entry.getKey();
            HashMap<String, Integer> num = entry.getValue();

            //����·����ȡ����
            int index = name.lastIndexOf("/");
            String className = name.substring(index+1,name.length()-5);

            String mapFirstBody = null;
            if(Constants.SMELL.containsKey(smellFirst)){
                if(Constants.SMELL.get(smellFirst).containsKey(name)){
                    mapFirstBody = Constants.SMELL.get(smellFirst).get(name);
                }
            }

            String mapSecondBody = null;
            if(Constants.SMELL.containsKey(smellSencond)){
                if(Constants.SMELL.get(smellSencond).containsKey(name)){
                    mapSecondBody = Constants.SMELL.get(smellSencond).get(name);
                }
            }
            StringBuilder sb = new StringBuilder();
            if(mapFirstBody != null){
                sb.append(mapFirstBody);
                sb.append("\n");
                sb.append("\n");
            }
            if(mapSecondBody != null){
                sb.append(mapSecondBody);
            }

            if(mapFirstBody != null && mapSecondBody != null) {
                //������ζ����
                isTWO = true;
                try {
                    CreateFile.createFile(sb.toString(),smellTwo,""+ISTWO++,isTWO);
                } catch (Exception exception) {
                    exception.printStackTrace();
                }
            }else{

                // �ѵ�����ζ����� Ҳ�Ž���������map

                isTWO = false;

                String noBody = mapFirstBody == null ? mapSecondBody : mapFirstBody;
                String noSmellName = mapFirstBody == null ? smellSencond : smellFirst;

                Constants.setNo(noSmellName,className,noBody);

//                try {
//                    CreateFile.createFile(sb.toString(),smellTwo,""+NOTTWO++,isTWO);
//                } catch (Exception exception) {
//                    exception.printStackTrace();
//                }

            }

        }

    }

//    /**
//     *
//     * @param smellFirst:����Constans��ĳ�����ζ��
//     * @param smellSencond:����Constans��ĳ�����ζ��
//     * @param twoSmellName:��ζ������д��ʽ����and���ӣ����磺SFLandMIM
//     */
//    public static void createTwoSmell(String smellFirst, String smellSencond, String twoSmellName){
//        smellTwo += twoSmellName;
////        System.out.println("------------------MAP-----------------------");
////        Constants.HMAP.forEach((a, b) -> System.out.println(a+"-----------"+b));
////        System.out.println("------------------MAP-----------------------");
////        System.out.println("------------------SMELL-----------------------");
////        Constants.SMELL.forEach((a, b) -> System.out.println(a+"-----------"+b));
////        System.out.println("------------------SMELL-----------------------");
//        HashMap<String, HashMap<String,Integer>> map = Constants.HMAP;
//        Set<Map.Entry<String, HashMap<String, Integer>>> entries = map.entrySet();
//        for(Map.Entry<String, HashMap<String, Integer>> entry:entries){
//            String name = entry.getKey();
//            HashMap<String, Integer> num = entry.getValue();
////            System.out.println(name + " -----" + num);
////            System.out.println(num.size());
////            System.out.println(num);
//
//            HashMap<String, List<String>> FirstMap = null;
//            List<String> FirstBodyList = null;
//            boolean flagFirst = false;
//
//            if(Constants.SMELL.containsKey(smellFirst)){
////                FirstMap = Constants.SMELL.get(smellFirst);
//                if(FirstMap.containsKey(name)){
//                    FirstBodyList  = FirstMap.get(name);
//                    flagFirst = true;
//                }
//            }
//            HashMap<String,List<String>> SecondMap = null;
//            List<String> SecondBodyList = null;
//            boolean flagSecond = false;
//            if(Constants.SMELL.containsKey(smellSencond)){
////                SecondMap = Constants.SMELL.get(smellSencond);
//                if(SecondMap.containsKey(name)){
//                    SecondBodyList = SecondMap.get(name);
//                    flagSecond = true;
//                }
//            }
//
//            int index = name.lastIndexOf("/");
//            String className = name.substring(index+1,name.length()-5);
//
//            if(num.size() > 1){
//
//                isTWO = true;
//
////                for (LegacyClass legacyClass : LegacySystem.getInstance().getAllClasses()) {
////                    System.out.println("name:"+legacyClass.getName());
////                    System.out.println("path:"+legacyClass.getPath());
////                    if(legacyClass.getPath().equals(name)){
//
////                        System.out.println(name);
//
//
////                StringBuilder sb = new StringBuilder(SLFBody);
////                sb.append("\n");
////                sb.append(MIMBody);
//
////                int numOfFile = 0;
////                for(int i = 0; i < SecondBodyList.size(); i++){
////                    try {
////                        CreateFile.createFile(SecondBodyList.get(i),smellTwo,className+"_"+"SLF"+numOfFile++,isSFLAndMIM);
////                    } catch (Exception exception) {
////                        exception.printStackTrace();
////                    }
////                }
////                for(int i = 0; i < MIMBodyList.size(); i++){
////                    try {
////                        CreateFile.createFile(MIMBodyList.get(i),smellTwo,className+"_"+"MIM"+numOfFile++,isSFLAndMIM);
////                    } catch (Exception exception) {
////                        exception.printStackTrace();
////                    }
////                }
//                for(int i = 0; i < SecondBodyList.size(); i++){
//                    StringBuilder sb = new StringBuilder(SecondBodyList.get(i));
//                    sb.append("\n");
//                    sb.append("\n");
//                    for(int j = 0; j < FirstBodyList.size(); j++){
//                        int startIndex = sb.length();
//                        sb.append(FirstBodyList.get(j));
//                        try {
//                            CreateFile.createFile(sb.toString(),smellTwo,ISTWO+++"",isTWO);
//                        } catch (Exception exception) {
//                            exception.printStackTrace();
//                        }
//                        int endIndex = startIndex + FirstBodyList.get(j).length();
//                        sb.delete(startIndex,endIndex);
//
//                    }
//                }
//
//
////                    }
//
////                }
//
//
//            }
//
//            if(!flagFirst || !flagSecond){
//                //û�й��� ���ڸ�����,  only one
//                isTWO = false;
//
//                if(FirstBodyList != null || SecondBodyList != null){
//
//                    if(FirstBodyList!=null){
//
//                        for(int i = 0; i < FirstBodyList.size(); i++){
//                            try {
//                                CreateFile.createFile(FirstBodyList.get(i),smellTwo, NOTTWO+++"",isTWO);
//                            } catch (Exception exception) {
//                                exception.printStackTrace();
//                            }
//                        }
//                    }
//                    if(SecondBodyList!=null){
//
//                        for(int i = 0; i < SecondBodyList.size(); i++){
//                            try {
//                                CreateFile.createFile(SecondBodyList.get(i),smellTwo,NOTTWO+++"",isTWO);
//                            } catch (Exception exception) {
//                                exception.printStackTrace();
//                            }
//                        }
//                    }
//
//                }
//
//            }
//
//
//
////            System.out.println(entry);
//        }
//
//
//        System.out.println("------------------MAP-----------------------");
//    }
}
