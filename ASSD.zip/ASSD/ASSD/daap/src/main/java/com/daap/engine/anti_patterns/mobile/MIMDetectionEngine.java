package com.daap.engine.anti_patterns.mobile;

import com.daap.model.DetectedInstance;
import com.daap.model.LegacyClass;
import com.daap.model.LegacySystem;
//import com.daap.util.CreateFile;
import com.daap.ui.ASD;
import com.daap.util.Constants;
import com.daap.util.Helper;
import com.daap.util.ResultDocument;
import com.github.javaparser.ast.NodeList;
import com.github.javaparser.ast.body.FieldDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.stmt.Statement;


import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by ZHUWEI on 7/21/2022.
 */
public class MIMDetectionEngine {
    private static ArrayList<MethodDeclaration> isMimList=new ArrayList<>();
    private static ArrayList<MethodDeclaration> notMimList=new ArrayList<>();
    private static int totalTest,totalMethod;

    private static final int DIT = 6;
    private static int total = 0;

    public static String smell = "MIM";
    private static boolean isMIM = false;
    private static int ISMIM = 0;
    private static int NOTMIM = 0;

    public static void reset(){
        isMIM = false;
        ISMIM = 0;
        NOTMIM = 0;
        isMimList.clear();
        notMimList.clear();
        total = 0;
        totalTest = 0;
        totalMethod = 0;
    }

    public MIMDetectionEngine() {
    }
    private static void called_Filter1(MethodDeclaration methodDeclaration,ArrayList<MethodDeclaration> nonMIMsmellyArrayList,ArrayList<MethodDeclaration> isMIMsmellyArrayList){

        if(nonMIMsmellyArrayList.size()==0||isMIMsmellyArrayList.size()==0)
            return;
        int size=nonMIMsmellyArrayList.size();
        for (int i = 0; i < nonMIMsmellyArrayList.size(); i++) {
            for (Statement statement: methodDeclaration.getBody().get().getStatements()) {
//                System.out.println("size=="+size+"==state"+methodDeclaration.getBody().get().getStatements().size());
                //����non�����method����û�е���non����
                if(statement.toString().contains(nonMIMsmellyArrayList.get(i).getName().toString())){
//                    System.out.println(statement.toString()+"====="+nonMIMsmellyArrayList.get(i).getName().toString());
                    nonMIMsmellyArrayList.add(methodDeclaration);
//                    size++;���ܼ���
                    isMIMsmellyArrayList.remove(methodDeclaration);
                    //����һ����mim���Ƴ�����method������Ҫ������������ǲ�����mim���б�����
                    called_Filter2(nonMIMsmellyArrayList,isMIMsmellyArrayList ,methodDeclaration);
                    return;
                }

            }
        }

    }

    private static void called_Filter2(ArrayList<MethodDeclaration> nonMIMSmellyArrayList,ArrayList<MethodDeclaration> isMIMsmellyArrayList, MethodDeclaration methodDeclaration) {
        if(nonMIMSmellyArrayList.size()<=0||isMIMsmellyArrayList.size()<=0){
            return;
        }
        //�ж�ÿһ����MIM�ķ����Ƿ���õ�ǰnoMIM
        for (int i = 0; i < isMIMsmellyArrayList.size(); i++) {
            for (Statement statement:isMIMsmellyArrayList.get(i).getBody().get().getStatements()) {
                if(statement.toString().contains(methodDeclaration.getNameAsString())){
                    //��������ת�Ƶ�noMIM
                    MethodDeclaration method_1=isMIMsmellyArrayList.get(i);
                    nonMIMSmellyArrayList.add(method_1);

                    isMIMsmellyArrayList.remove(method_1);
                    i--;//�����ˣ����һ�������ǰ������ˣ�arraylist��С��,���������һ��
                    called_Filter2(nonMIMSmellyArrayList,isMIMsmellyArrayList,method_1);
                    //�ݹ���ü���Ѱ�����ת��ΪnonMIM�ķ����Ƿ��б�����MIM��������
                    break;
                }
            }
        }
    }

    private static boolean intersection(List<FieldDeclaration> allFields, NodeList<Statement> fieldsAccessList) {

        for (FieldDeclaration fieldDeclaration :allFields) {
            for (Statement statement : fieldsAccessList) {
                if (statement.toString().contains(fieldDeclaration.getVariable(0).getNameAsString())) {
//                    System.out.println(statement.toString()+"+++"+fieldDeclaration.getVariable(0).getNameAsString());
                    return true;
                }
            }
        }
        return false;
    }

    private static List<FieldDeclaration> getAllFields(LegacyClass legacyClass){
        List<FieldDeclaration> list=new ArrayList<>();
        //��ȡ���������
        list.addAll(legacyClass.getFieldDeclarations());
//        System.out.println(list);
        if(legacyClass.getClassOrInterfaceDeclaration().getExtendedTypes().size()!=0) {
//            System.out.println(legacyClass.getName() + "**parentClass**:\n" + legacyClass.getClassOrInterfaceDeclaration().getExtendedTypes().get(0).toString());
            for (LegacyClass lc : LegacySystem.getInstance().getAllClasses()) {
                if (lc.getName().equals(legacyClass.getClassOrInterfaceDeclaration().getExtendedTypes().get(0).toString())) {
                    //�õ��˸��࣬�������໹��û�и���
                    list.addAll(getAllFields(lc));
                    return list;
                }
            }
        }
        return list;
    }

    public static void detect() {

        reset();

        ASD.writeMessage("M I M:\n");
        ResultDocument resultDocument = new ResultDocument(Constants.A_MEMBER_IGNORING_METHOD);
        ArrayList<DetectedInstance> detectedInstances = new ArrayList<>();
        total = 0;  // check it.

        total=0;
        totalTest=0;
        totalMethod=0;
        System.out.println("======================STARTED-------------------");


        for (LegacyClass legacyClass : LegacySystem.getInstance().getAllClasses()) {
//            createMyMIMData("\n<tr>");
//            createMyMIMData("\n<td>"+legacyClass.getPath()+"</td>");
            isMimList.clear();
            notMimList.clear();
            for (MethodDeclaration methodDeclaration : legacyClass.getMethodDeclarations()) {
                totalMethod++;
                if (methodDeclaration.isStatic()||isNullMethod2(methodDeclaration)||isOverride2(methodDeclaration)) {
                    notMimList.add(methodDeclaration);
                    continue;
                }

                NodeList<Statement> fieldsAccessList = getFieldsAccessList(methodDeclaration);

                if(!intersection(getAllFields(legacyClass),fieldsAccessList)){
                    total++;
                    isMimList.add(methodDeclaration);
                    called_Filter1(methodDeclaration,notMimList,isMimList);
                    continue;
                }

                notMimList.add(methodDeclaration);
            }


            for(MethodDeclaration methodDeclaration : isMimList){

                ASD.writeMessage("Class Name: " + legacyClass.getName()+"testtestest"
                        + "\nPath: " + legacyClass.getPath() + "\n"
                );

//                    Constants.setHmap(legacyClass.getName(),Constants.A_MEMBER_IGNORING_METHOD);
//                    Helper.writeDoc(table, legacyClass, total);
                Constants.setHmap(legacyClass.getPath(),Constants.A_MEMBER_IGNORING_METHOD);

                Constants.setSmell(Constants.A_MEMBER_IGNORING_METHOD,legacyClass.getPath(),methodDeclaration.clone().toString());




                boolean exists = true;
                for (DetectedInstance detectedInstance: detectedInstances){
                    if (detectedInstance.getName().equals(legacyClass.getName())){
                        detectedInstance.increment();
                        exists = false;
                        break;
                    }
                }
                if (exists){
                    detectedInstances.add(new DetectedInstance(legacyClass.getName(), legacyClass.getPath(), 1));
                }
                System.out.println("legacyClass: " + legacyClass.getName() + "   " + " methodDeclaration: " + methodDeclaration.getNameAsString());
                // break;
                System.out.println(methodDeclaration);

                isMIM = true;
                try {
                    com.daap.util.CreateFile.createFile(methodDeclaration.clone().toString(),smell,ISMIM+"",isMIM);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                ISMIM++;



            }
            isMIM = false;
            for(MethodDeclaration methodDeclaration : notMimList){
                try {
                    com.daap.util.CreateFile.createFile(methodDeclaration.clone().toString(),smell,NOTMIM+"",isMIM);
                } catch (Exception e) {
                    e.printStackTrace();
                }

                Constants.Nothing.add(methodDeclaration.clone().toString());

                Constants.setNo(Constants.A_MEMBER_IGNORING_METHOD,legacyClass.getName(),methodDeclaration.clone().toString());

            }
            NOTMIM++;



            totalTest+=isMimList.size();

//            createMyMIMData("\n<td>"+isMimList.size()+"</td>");
//            createMyMIMData("\n</tr>");


        }




        System.out.println("total: " + total+"===="+totalTest);
//        System.out.println("-----------------------------");
//        System.out.println(isMimList.size());
//        System.out.println("isMIM LIST:");;
//        isMimList.forEach(a -> System.out.println(a));
//        System.out.println("-----------------------------");
//        System.out.println(notMimList.size());
//        System.out.println("noMIM LIST:");;
//        notMimList.forEach(a -> System.out.println(a));


//        createMyMIMData("\n</table>");
//        createMyMIMData("\n## appTotal:"+totalTest+"\n");
//        createMyMIMData("\n## methodTotal:"+totalMethod+"\n");
//        CreateFile.createMyMIMData_2("<tr>"+
//                "\n<td>"+ ASD.projectSrcFolder +"</td>"
//                +"\n<td>"+totalTest+"</td>"
//                +"\n</tr>");


        ASD.writeMessage("Total: " + total);
        ASD.detectionDone();

        System.out.println("======================FINISHED-------------------");

        int srNo = 1;
        for (DetectedInstance detectedInstance : detectedInstances) {
            Helper.writeDoc(resultDocument, detectedInstance, srNo++);
        }
        Helper.writeFile(resultDocument);

    }

    private static boolean isNullMethod2(MethodDeclaration methodDeclaration) {
        try {
            if (methodDeclaration.getBody().get().getStatements().size()==0){
                return true;
            }else {
                return false;
            }
        }catch (Exception e){
            return true;
        }
    }

    private static boolean isOverride2(MethodDeclaration methodDeclaration) {
        for (int i = 0; i < methodDeclaration.getAnnotations().size(); i++) {
            if (methodDeclaration.getAnnotations().get(i).toString().contains("@Override")){
                return  true;
            }
        }
        return false;
    }

    private static   boolean isNullMethod(MethodDeclaration methodDeclaration){
        String regex="\\w";
        try {
            StringBuffer stringBuffer = new StringBuffer(methodDeclaration.clone().toString());
            stringBuffer = new StringBuffer(stringBuffer.substring(stringBuffer.indexOf("{") + 1, stringBuffer.lastIndexOf("}")));
            Pattern p = Pattern.compile(regex);
            Matcher m = p.matcher(stringBuffer.toString());
            if(m.find()&&stringBuffer.toString().indexOf(";")!=-1){
                return false;
            }else {
                return true;
            }
        }catch (Exception e){
            return true;
        }
    }
    private static   boolean isOverride(MethodDeclaration methodDeclaration){
        String regex="@Override";
        try {
            StringBuffer stringBuffer = new StringBuffer(methodDeclaration.clone().toString());
            stringBuffer = new StringBuffer(stringBuffer.substring(0,stringBuffer.indexOf("{") -1));

            if(stringBuffer.toString().indexOf(regex)!=-1){
                return true;
            }else {
                return false;
            }
        }catch (Exception e){
            return false;
        }
    }
    private static   NodeList<Statement> getFieldsAccessList(MethodDeclaration methodDeclaration) {

        NodeList<Statement> statements = new NodeList<>();

        try {
            statements = methodDeclaration.getBody().get().getStatements();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return statements;

    }

}
