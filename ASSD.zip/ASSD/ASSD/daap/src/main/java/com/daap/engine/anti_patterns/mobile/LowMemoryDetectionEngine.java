package com.daap.engine.anti_patterns.mobile;

import com.daap.model.DetectedInstance;
import com.daap.model.LegacyClass;
import com.daap.model.LegacySystem;
import com.daap.ui.ASD;
import com.daap.util.Constants;
import com.daap.util.CreateFile;
import com.daap.util.Helper;
import com.daap.util.ResultDocument;
import com.github.javaparser.ast.body.MethodDeclaration;

import java.util.ArrayList;

/**
 * Created by Azhar on 9/21/2017.
 */
public class LowMemoryDetectionEngine {//4 split lowmemory

//    private static int total = 0;
    private static boolean isLM = false;
    private static int ISLM = 0;
    private static int NOTLM = 0;
    public static String smell = "LM";

    public static void reset(){
        isLM = false;
        ISLM = 0;
        NOTLM = 0;
    }

//    private static final String fileName = "No Low Memory Resolver";

    public static void detect() {
        reset();
//        XWPFDocument doc;
//        XWPFTable table;
//        doc = new XWPFDocument();
//        table = doc.createTable();
////        Helper.writeHeader(table, "No Low Memory Resolver");
//        table.getRow(0).getCell(0).setText("Sr. No");
//        table.getRow(0).createCell().setText("Class");
////        table.getRow(0).createCell().setText("Method");
//        table.getRow(0).createCell().setText("Path");


//        ASD.clearConsole();
        ResultDocument resultDocument = new ResultDocument(Constants.A_LOW_MEMORY);
        ArrayList<DetectedInstance> detectedInstances = new ArrayList<>();

        int total = 0;
        System.out.println("======================STARTED-------------------");
        ASD.writeMessage("Low Memory:\n");
        for (LegacyClass legacyClass : LegacySystem.getInstance().getAllClasses()) {
            boolean flag = false;
            if (legacyClass.getParentClass() != null && legacyClass.getParentClass().contains("Activity")) {
                if (isLowMemoryMethodEsists(legacyClass)) {

                    total++;
//                    ASD.writeMessage("Class: " + legacyClass.getName());
                    ASD.writeMessage("Class Name: " + legacyClass.getName()
                            + "\nPath: " + legacyClass.getPath() + "\n"
                    );

//                    Constants.setHmap(legacyClass.getName(),Constants.A_LOW_MEMORY);
//                    Helper.writeDoc(table, legacyClass, total);
                    Constants.setHmap(legacyClass.getPath(),Constants.A_LOW_MEMORY);

                    Constants.setSmell(Constants.A_LOW_MEMORY,legacyClass.getPath(),legacyClass.toString());

                    flag = true;
                    isLM = true;
                    try {
                        CreateFile.createFile(legacyClass.toString(),smell,ISLM+"",isLM);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    ISLM++;



                    boolean exists = true;
                    for (DetectedInstance detectedInstance: detectedInstances){
                        if (detectedInstance.getName().equals(legacyClass.getName())){
                            detectedInstance.increment();
                            exists = false;
                            break;
                        }
                    }
                    if (exists){
                        detectedInstances.add(new DetectedInstance(legacyClass.getName(), legacyClass.getPath(), 1));
                    }

                    System.out.println("legacyClass: " + legacyClass.getName());
                }
            }
            if(!flag){

                Constants.Nothing.add(legacyClass.toString());

                isLM = false;
                try {
                    CreateFile.createFile(legacyClass.toString(),smell,NOTLM+"",isLM);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                NOTLM++;
            }
        }

        System.out.println("total: " + total);
        ASD.writeMessage("Total: " + total);
        ASD.detectionDone();
//        Helper.writeFile(doc, "LowMemory");
        System.out.println("======================FINISHED-------------------");
        int srNo = 1;
        for (DetectedInstance detectedInstance : detectedInstances) {
            Helper.writeDoc(resultDocument.getTable(), detectedInstance, srNo++);
        }
        Helper.writeFile(resultDocument.getDoc(), "LowMemory");
    }

    private static boolean isLowMemoryMethodEsists(LegacyClass legacyClass) {
        boolean isLowMemoryExists = true;
        for (MethodDeclaration methodDeclaration : legacyClass.getMethodDeclarations()) {
            if (methodDeclaration.getNameAsString().equals("onLowMemory")) {
                return false;
            }
        }
        return isLowMemoryExists;
    }
}
