package com.daap.arrangement;

import com.daap.ui.ASD;
import com.daap.util.Constants;

import java.util.HashMap;

public class AnalyseClass {
    public static void xchange(){
        Object bf[] = Constants.HMAP.keySet().toArray();//���·��
        String af[] = new String[bf.length];//
        {//ת��
            for (int i=0;i< bf.length;i++) {
                if((bf[i].toString()).contains("/app/src/test/java/")||(bf[i].toString()).contains("/app/src/androidTest/java/")) {
                    Constants.HMAP.remove(bf[i].toString());
                    af[i]="";
                    continue;
                }
                StringBuffer sb = new StringBuffer(bf[i].toString());

                int index1 = sb.indexOf("/app/src/main/java/");
                int index2 = sb.indexOf("/app/src/main/java/") + 19;
                if(index1 > 0 && index1 < sb.length() - 1 && index2 > 0 && index2 < sb.length()){
                    sb.delete(sb.indexOf("/app/src/main/java/"), sb.indexOf("/app/src/main/java/") + 19);
                }
                int index3 = sb.lastIndexOf(".java");
                int index4 = sb.lastIndexOf(".java") + 5;
                if(index3 > 0 && index3 < sb.length() - 1 && index4 > 0 && index4 < sb.length()){
                    sb.delete(sb.lastIndexOf(".java"), sb.lastIndexOf(".java") + 5);
                }
                String sx = sb.toString().replace("/", ".");
                af[i] = sx;


            }
        }

        for(int i=0;i<bf.length;i++){
            if(Constants.HMAP.containsKey(bf[i].toString())) {
                HashMap<String, Integer> hm = Constants.HMAP.get(bf[i].toString());
                Constants.HMAP.remove(bf[i].toString());
                Constants.HMAP.put(af[i], hm);
            }
        }
    }

    public static void Analyse(){//ɸѡ��ѡ��ζ���������
        ASD.clearConsole();
        Object allClass[]= Constants.HMAP.keySet().toArray();
        boolean consoleISEmpty=true,allSmell;
        ASD.writeMessage("Class:");
        for(Object ac:allClass){//ÿ����
            allSmell=true;
            for(String s:Constants.SLIST) {//��ǰ���ÿ����ζ��������
                if (!Constants.HMAP.get(ac).containsKey(s)){//����˴��ͱ�ʾ��ǰ�಻�ǰ������������
                    allSmell=false;
                }
            }
            if(allSmell) {
                ASD.writeMessage(ac.toString());
                consoleISEmpty=false;
            }
        }
        if (consoleISEmpty){
            ASD.clearConsole();
            ASD.writeMessage("NO SUCH CLASS !Look at the pop-up window");
        }
    }


}
