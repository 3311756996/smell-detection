package com.daap.ui;

import com.daap.engine.anti_patterns.mobile.*;
import com.daap.model.LegacyClass;
import com.daap.model.LegacySystem;
import com.daap.parse.MyDpvdVisitor;
import com.daap.parse.MyDpvdXmlVisitor;
import com.daap.arrangement.AnalyseClass;
import com.daap.arrangement.DataWin;
import com.daap.util.Constants;
import com.daap.util.CreateFile;

import java.awt.*;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.File;
import java.util.*;
import java.util.List;
import java.util.Timer;

import javax.swing.*;

/**
 * Created by ZHUWEI on 12/1/2021.
 */
public class ASD {
    public static String projectSrcFolder = null;//string of folder
    public static boolean parseoccured = false;
    private static ParsingStages parsingStage;
    private static JButton btnDetect;
    private static JLabel detectionLoader, parsingLoader;
    private static Constants.SELECTED_AP_ANDROID selectedApAndroid = Constants.SELECTED_AP_ANDROID.NONE;

    private static int BUTTON_FONT_SIZE = 24;
    static JTextArea jtaConsole;
    static JLabel jLabelAntiPattern;

    private static int numOfBoxSelected = 0;
    private static List<JCheckBox> listBox = new ArrayList<JCheckBox>();
    private static List<Object> listSmellDetection = new ArrayList<Object>();

    private static JCheckBox Jcb_FE_MIM,Jcb_CC,Jcb_FE,Jcb_MIM,Jcb_LM,Jcb_SFL,Jcb_LIC,Jbc_BC,Jbc_DD,Jbc_DWL,Jbc_IDP,Jbc_IDS,Jbc_ISG,Jbc_VC,Jbc_LT,Jbc_PD,Jbc_RAM,Jbc_SB,Jbc_SC,Jbc_SV,Jbc_UC;
    public static void main(String[] args) {

        JPanel apanel,bpanel;
        apanel=new JPanel();
        bpanel=new JPanel();
        setPanel(apanel);
        setPanel(bpanel);
        bpanel.setLayout(new FlowLayout());
        apanel.setLayout(new GridLayout(3,2,8,10));

        {
            Jcb_MIM = new JCheckBox("MIM");
            Jcb_FE = new JCheckBox("FE *");
            Jcb_CC = new JCheckBox("CC *");
            Jcb_FE_MIM = new JCheckBox("FE&MIM *");
            Jcb_LM = new JCheckBox("LM");
            Jcb_SFL = new JCheckBox("SFL");
            Jcb_LIC = new JCheckBox("LIC");
            Jbc_BC = new JCheckBox("BC");
            Jbc_DD = new JCheckBox("DD");
            Jbc_DWL = new JCheckBox("DWL");
            Jbc_IDP = new JCheckBox("IDFP");
            Jbc_IDS = new JCheckBox("IDS");
            Jbc_ISG = new JCheckBox("ISG");
            Jbc_VC = new JCheckBox("VC");
            Jbc_LT = new JCheckBox("LT");
            Jbc_PD = new JCheckBox("PD");
            Jbc_RAM  = new JCheckBox("RAM");
            Jbc_SB = new JCheckBox("SB");
            Jbc_SC = new JCheckBox("SC");
            Jbc_SV = new JCheckBox("SV");
            Jbc_UC = new JCheckBox("UC");
        }

        setMyStyle();

        //set frame and layout
        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setTitle("ASSD-(Android-specific Smell Detector) V2.0");
        ImageIcon icon=new ImageIcon("resources/images/icon.png");
        frame.setIconImage(icon.getImage());
        JPanel panel = (JPanel) frame.getContentPane();//

        panel.setLayout(null);

        JLabel title = new JLabel("Android-specific Smell Detector (ASSD)");
        title.setFont(new Font("Courier New", Font.ITALIC + Font.BOLD, 40));
        panel.add(title);
        Dimension labelSize = title.getPreferredSize();
        title.setBounds(Constants.FRAME_WITH/2 - labelSize.width / 2, 60, labelSize.width, labelSize.height);

        JPanel jpBrowseProject = new JPanel();


        panel.add(jpBrowseProject);
//JFilePick set
        final JFilePicker browseProjectPicker = new JFilePicker("Android Project Folder", "Browse", JFilePicker.type.Project);
        browseProjectPicker.setMode(JFilePicker.MODE_SAVE);
        jpBrowseProject.add(browseProjectPicker);
        jpBrowseProject.setSize(jpBrowseProject.getPreferredSize().width+200, 200);
        setContainL(jpBrowseProject, title);  //设置Andriod Project Folder标签和Browse按钮，通过自定义的JFilePicker类实现了可以打开本地资源选择文件

//change change
//        panel.add(jLabelAntiPattern);
        panel.add(apanel);
        panel.add(bpanel);
//        jLabelAntiPattern.setBounds(jpBrowseProject.getX() + 80, jpBrowseProject.getY() + 60, 200, 50);

//        JCheckBox Jcb_MIM = new JCheckBox("Method Ignoring Method");
//        JCheckBox Jcb_LM = new JCheckBox("Low Memory");
//        JCheckBox Jcb_SFL = new JCheckBox("Slow for Loop");
        //change OXT change
//        final JComboBox cbAntiPatternsAndroid = new JComboBox<>(new String[]{"Choose Android Anti Pattern",
//                Constants.A_MEMBER_IGNORING_METHOD,Constants.A_LOW_MEMORY,

//                Constants.A_INTERNAL_GETTER_SETTER, Constants.A_INEFFICIENT_DATA_FORMAT_PARSER,
//                Constants.A_INEFFICIENT_DATA_STRUCTURE, Constants.A_LEAKING_THREAD,

//                Constants.A_SLOW_FOR_LOOP,

//                Constants.A_PUBLIC_DATA, Constants.A_DURABLE_WAKE_LOCK,
//                Constants.A_RIGID_ALARM_MANAGER, Constants.A_UNCLOSED_CLOSEABLE, Constants.A_LEAKING_INNER_CLASS,
//                Constants.A_DEBUGGABLE_RELEASE, Constants.A_STATIC_VIEW, Constants.A_STATIC_CONTEXT,
//                Constants.A_STATIC_BITMAP, Constants.A_VIEWS_IN_COLLECTION, Constants.A_COLLECTION_BITMAPS,
//                Constants.A_DROPPED_DATA, Constants.A_UNTOUCHABLE, Constants.A_UNCONTROLLED_FOCUS_ORDER,
//                Constants.A_NESTED_LAYOUT, Constants.A_NOT_DESCRIPTIVE_UI, Constants.A_CONFIG_CHANGES, Constants.A_OVERDRAWN_PIXEL

//        });
//change change
//        cbAntiPatternsAndroid.setSize(220, 35);

//        cbAntiPatternsAndroid.setLocation(jLabelAntiPattern.getX() + 200, jLabelAntiPattern.getY() + 10);
//        Jcb_MIM.setLocation(jLabelAntiPattern.getX() + 200, jLabelAntiPattern.getY() + 10);

//        cbAntiPatternsAndroid.setEditable(true);
//        cbAntiPatternsAndroid.getEditor().getEditorComponent().setFocusable(false);
//        cbAntiPatternsAndroid.setVisible(true);
//        apanel.add(cbAntiPatternsAndroid);

//        panel.add(cbAntiPatternsAndroid);

        {
            apanel.add(Jcb_LM);
            apanel.add(Jcb_MIM);
            apanel.add(Jcb_SFL);
            apanel.add(Jcb_LIC);
            apanel.add(Jbc_BC);
            apanel.add(Jbc_UC);
            apanel.add(Jbc_SV);
            apanel.add(Jbc_SC);
            apanel.add(Jbc_SB);
            apanel.add(Jbc_RAM);
            apanel.add(Jbc_PD);
            apanel.add(Jbc_LT);
            apanel.add(Jbc_VC);
            apanel.add(Jbc_ISG);
            apanel.add(Jbc_IDS);
            apanel.add(Jbc_IDP);
            apanel.add(Jbc_DWL);
            apanel.add(Jbc_DD);
//            apanel.add(new JLabel("                       "));

            apanel.add(Jcb_FE);
            apanel.add(Jcb_CC);
//            apanel.add(Jcb_FE_MIM);
        }
        apanel.setSize( 900, 100);
        setContainL(apanel,jpBrowseProject);
        jtaConsole = new JTextArea("");
        jtaConsole.setFont(new Font("Courier New", Font.BOLD, 20));

        jtaConsole.setBounds((int) (frame.getSize().width * 0.5)+150, apanel.getY() + 280, 1000, 300); //parsingLoader.getY() + 300
        JScrollPane jScrollPane = new JScrollPane(jtaConsole); //把文本域和下拉框组合在了一起

        //文本域和下拉框组合在一起之后放入了frame顶级容器
        frame.add(jScrollPane);
        jScrollPane.setBounds(100, 60, 1000, 200); // 200
        jScrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

        frame.setLayout(null);
        frame.setVisible(true);

        frame.setResizable(false);
        frame.setSize(Constants.FRAME_WITH, Constants.FRAME_HIEGHT);
        frame.setVisible(true);
        jScrollPane.setLocation(50, apanel.getY() + 100);
        jtaConsole.setLocation(2, jtaConsole.getY());
//change change
//        cbAntiPatternsAndroid.addActionListener(actionEvent -> {//2.choose anti patterns
//
//            JComboBox comboBox = (JComboBox) actionEvent.getSource();
//
//            Object selected = comboBox.getSelectedItem();
//
//            if (selected.toString().equals(Constants.CHOOSE_ANTI_PATTERN)) {
//                selectedApAndroid = Constants.SELECTED_AP_ANDROID.NONE;
//            } else if (selected.toString().equals(Constants.A_LEAKING_INNER_CLASS)) {
//                selectedApAndroid = Constants.SELECTED_AP_ANDROID.LEAKING_INNER_CLASS;
//            } else if (selected.toString().equals(Constants.A_MEMBER_IGNORING_METHOD)) {
//                selectedApAndroid = Constants.SELECTED_AP_ANDROID.MEMBER_IGNORING_METHOD;
//            } else if (selected.toString().equals(Constants.A_LEAKING_THREAD)) {
//                selectedApAndroid = Constants.SELECTED_AP_ANDROID.LEAKING_THREAD;
//            } else if (selected.toString().equals(Constants.A_INTERNAL_GETTER_SETTER)) {
//                selectedApAndroid = Constants.SELECTED_AP_ANDROID.INTERNAL_GETTER_SETTER;
//            } else if (selected.toString().equals(Constants.A_INEFFICIENT_DATA_STRUCTURE)) {
//                selectedApAndroid = Constants.SELECTED_AP_ANDROID.INEFFICIENT_DATA_STRUCTURE;
//            } else if (selected.toString().equals(Constants.A_INEFFICIENT_DATA_FORMAT_PARSER)) {
//                selectedApAndroid = Constants.SELECTED_AP_ANDROID.INEFFICIENT_DATA_FORMAT_PARSER;
//            } else if (selected.toString().equals(Constants.A_SLOW_FOR_LOOP)) {
//                selectedApAndroid = Constants.SELECTED_AP_ANDROID.SLOW_FOR_LOOP;
//            } else if (selected.toString().equals(Constants.A_PUBLIC_DATA)) {
//                selectedApAndroid = Constants.SELECTED_AP_ANDROID.PUBLIC_DATA;
//            } else if (selected.toString().equals(Constants.A_LOW_MEMORY)) {    //2.1
//                selectedApAndroid = Constants.SELECTED_AP_ANDROID.LOW_MEMORY;
//            } else if (selected.toString().equals(Constants.A_DURABLE_WAKE_LOCK)) {
//                selectedApAndroid = Constants.SELECTED_AP_ANDROID.DURABLE_WAKE_LOCK;
//            } else if (selected.toString().equals(Constants.A_RIGID_ALARM_MANAGER)) {
//                selectedApAndroid = Constants.SELECTED_AP_ANDROID.RIGID_ALARM_MANAGER;
//            } else if (selected.toString().equals(Constants.A_UNCLOSED_CLOSEABLE)) {
//                selectedApAndroid = Constants.SELECTED_AP_ANDROID.UNCLOSED_CLOSEABLE;
//            } else if (selected.toString().equals(Constants.A_STATIC_CONTEXT)) {
//                selectedApAndroid = Constants.SELECTED_AP_ANDROID.STATIC_CONTEXT;
//            } else if (selected.toString().equals(Constants.A_STATIC_VIEW)) {
//                selectedApAndroid = Constants.SELECTED_AP_ANDROID.STATIC_VIEW;
//            } else if (selected.toString().equals(Constants.A_STATIC_BITMAP)) {
//                selectedApAndroid = Constants.SELECTED_AP_ANDROID.STATIC_BITMAP;
//            } else if (selected.toString().equals(Constants.A_VIEWS_IN_COLLECTION)) {
//                selectedApAndroid = Constants.SELECTED_AP_ANDROID.VIEWS_IN_COLLECTION;
//            } else if (selected.toString().equals(Constants.A_COLLECTION_BITMAPS)) {
//                selectedApAndroid = Constants.SELECTED_AP_ANDROID.COLLECTION_BITMAPS;
//            } else if (selected.toString().equals(Constants.A_DEBUGGABLE_RELEASE)) {
//                selectedApAndroid = Constants.SELECTED_AP_ANDROID.DEBUGGABLE_RELEASE;
//            } else if (selected.toString().equals(Constants.A_DROPPED_DATA)) {
//                selectedApAndroid = Constants.SELECTED_AP_ANDROID.DROPPED_DATA;
//            } else if (selected.toString().equals(Constants.A_CONFIG_CHANGES)) {
//                selectedApAndroid = Constants.SELECTED_AP_ANDROID.CONFIG_CHANGES;
//            } else if (selected.toString().equals(Constants.A_NOT_DESCRIPTIVE_UI)) {
//                selectedApAndroid = Constants.SELECTED_AP_ANDROID.NOT_DESCRIPTIVE_UI;
//            } else if (selected.toString().equals(Constants.A_NESTED_LAYOUT)) {
//                selectedApAndroid = Constants.SELECTED_AP_ANDROID.NESTED_LAYOUT;
//            } else if (selected.toString().equals(Constants.A_UNTOUCHABLE)) {
//                selectedApAndroid = Constants.SELECTED_AP_ANDROID.UNTOUCHABLE;
//            } else if (selected.toString().equals(Constants.A_UNCONTROLLED_FOCUS_ORDER)) {
//                selectedApAndroid = Constants.SELECTED_AP_ANDROID.UNCONTROLLED_FOCUS_ORDER;
//            } else if (selected.toString().equals(Constants.A_OVERDRAWN_PIXEL)) {
//                selectedApAndroid = Constants.SELECTED_AP_ANDROID.OVERDRAWN_PIXEL;
//            }
//        });
        //change change
//        cbAntiPatternsAndroid.setEnabled(true);
//        Jcb_MIM.setEnabled(true);

        JButton btnParse = new JButton("Start Parsing");//3 start parsing
        btnParse.setEnabled(true);
        bpanel.add(btnParse);
        Dimension btnPredictSize = btnParse.getPreferredSize();
//        btnParse.setBounds(jLabelAntiPattern.getX() - 100, jLabelAntiPattern.getY() + 80, btnParse.getPreferredSize().width, btnParse.getPreferredSize().height);
//        btnParse.setBounds(apanel.getX() , apanel.getY() + 300, btnParse.getPreferredSize().width, btnParse.getPreferredSize().height);
//        btnParse.setSize(90, 25);
        btnParse.setFont(new Font("Arial", Font.BOLD, BUTTON_FONT_SIZE));
        parsingLoader = new JLabel(new ImageIcon("resources/images/35.gif"));
//        parsingLoader.setBounds(parsingLoader.getPreferredSize().width, parsingLoader.getPreferredSize().height, btnParse.getX(), btnParse.getY());
//        parsingLoader.setLocation(btnParse.getX() + btnParse.getPreferredSize().width / 2 - parsingLoader.getPreferredSize().width / 2, btnParse.getY() + 50);
        parsingLoader.setSize(100, 100);

        parsingLoader.setVisible(false);//

        btnDetect = new JButton("Detect Selected Code Smell");

        bpanel.add(btnDetect);
        btnDetect.setEnabled(false);
//        btnDetect.setBounds(btnParse.getX() + btnParse.getPreferredSize().width + 55, btnParse.getY(), btnDetect.getPreferredSize().width, btnDetect.getPreferredSize().height);
//        btnDetect.setSize(270/2, 50/2);
        btnDetect.setFont(new Font("Arial", Font.BOLD, BUTTON_FONT_SIZE));

        JButton btnReset = new JButton("Reset");
        btnReset.setEnabled(true);
        bpanel.add(btnReset);
//        btnReset.setBounds(btnDetect.getX() + btnDetect.getPreferredSize().width + 30, btnDetect.getY(), btnReset.getPreferredSize().width, btnReset.getPreferredSize().height);
//        btnReset.setSize(120/2, 50/2);
        btnReset.setFont(new Font("Arial", Font.BOLD, BUTTON_FONT_SIZE));

        detectionLoader = new JLabel(new ImageIcon("resources/images/35.gif"));
//        detectionLoader.setBounds(parsingLoader.getPreferredSize().width, parsingLoader.getPreferredSize().height, btnParse.getX(), btnParse.getY() - 200);
//        detectionLoader.setLocation(btnDetect.getX() + btnDetect.getPreferredSize().width / 2 - detectionLoader.getPreferredSize().width / 2, btnDetect.getY() + 50);
        detectionLoader.setSize(100, 100);

        detectionLoader.setVisible(false);

        //设置bpanel的位置（bpanel包含了三个按钮）
        bpanel.setBounds(apanel.getX() - 115 , apanel.getY() + 300, btnParse.getPreferredSize().width*4, btnParse.getPreferredSize().height*2);

        panel.add(parsingLoader);
        panel.add(detectionLoader);


        final ButtonGroup buttonGroup = new ButtonGroup();

        //监听Parse按钮，分别有三个状态，弹出提示框提示
        btnParse.addActionListener(arg0 -> {//3
            if (parsingStage == ParsingStages.PARSING) {//ing
                JOptionPane.showMessageDialog(new JFrame(), "Parsing is in progress, Please wait.", "Parsing",
                        JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            if (parsingStage == ParsingStages.DONE) {//completed
                JOptionPane.showMessageDialog(new JFrame(), "Parsing completed, Please start detection process.", "Parsing",
                        JOptionPane.INFORMATION_MESSAGE);
                return;
            }

            if (projectSrcFolder == null) {//choose error
                JOptionPane.showMessageDialog(new JFrame(), "Please Select a valid path to parse the source-code", "ERROR",
                        JOptionPane.ERROR_MESSAGE);
            } else {//3.1
                parsingStage = ParsingStages.PARSING;
//                    isParsing = true;

                parse();//3.1
            }
        });

        //检测按钮Detect
        btnDetect.addActionListener(arg0 -> {
            ASD.clearConsole();
            Constants.HMAP.clear();
            Constants.SLIST.clear();
            boolean Uchoose=true;
            //判断选择了哪些
            if(Jcb_LM.isSelected()){
//                listSmellDetection.add(LowMemoryDetectionEngine.)
                listBox.add(Jcb_LM);
                numOfBoxSelected++;
                Uchoose=false;
                Constants.SLIST.add(Constants.A_LOW_MEMORY);
                detectionLoader.setVisible(true);
                LowMemoryDetectionEngine.detect();
            }if(Jcb_MIM.isSelected()) {
                listBox.add(Jcb_MIM);
                numOfBoxSelected++;
                Uchoose=false;
                Constants.SLIST.add(Constants.A_MEMBER_IGNORING_METHOD);
                detectionLoader.setVisible(true);
                MIMDetectionEngine.detect();
            }if(Jcb_FE.isSelected()) { //ZW
                listBox.add(Jcb_FE);
                numOfBoxSelected++;
                Uchoose=false;
                Constants.SLIST.add(Constants.A_FEATURE_ENVY);
                detectionLoader.setVisible(true);
                FeatureEnvyDetectionEngine.detect();
            }if(Jcb_CC.isSelected()){
                listBox.add(Jcb_CC);
                numOfBoxSelected++;
                Uchoose=false;
                Constants.SLIST.add(Constants.A_COMPLEX_CLASS);
                detectionLoader.setVisible(true);
                ComplexClassDetectionEngine.detect();
            }

//            if(Jcb_FE_MIM.isSelected()) { //ZW
//                Uchoose=false;
//                Constants.SLIST.add(Constants.A_FE_MIM);
//                detectionLoader.setVisible(true);
//                FEAndMIMDetectionEngine.detect();
//            }
            if(Jcb_SFL.isSelected()){
                listBox.add(Jcb_SFL);
                numOfBoxSelected++;
                Uchoose=false;
                Constants.SLIST.add(Constants.A_SLOW_FOR_LOOP);
                detectionLoader.setVisible(true);
                SlowForLoopDetectionEngine.detect();
            }if(Jcb_LIC.isSelected()){
                listBox.add(Jcb_LIC);
                numOfBoxSelected++;
                Uchoose=false;
                Constants.SLIST.add(Constants.A_LEAKING_INNER_CLASS);
                detectionLoader.setVisible(true);
                LeakingInnerClassDetectionEngine.detect();
            }if(Jbc_BC.isSelected()){
                listBox.add(Jbc_BC);
                numOfBoxSelected++;
                Uchoose=false;
                Constants.SLIST.add(Constants.A_COLLECTION_BITMAPS);
                detectionLoader.setVisible(true);
                BitmapsCollectionDetectionEngine.detect();
            }if(Jbc_DD.isSelected()){
                listBox.add(Jbc_DD);
                numOfBoxSelected++;
                Uchoose=false;
                Constants.SLIST.add(Constants.A_DROPPED_DATA);
                detectionLoader.setVisible(true);
                DroppedDataDetectionEngine.detect();
            }if(Jbc_DWL.isSelected()){
                listBox.add(Jbc_DWL);
                numOfBoxSelected++;
                Uchoose=false;
                Constants.SLIST.add(Constants.A_DURABLE_WAKE_LOCK);
                detectionLoader.setVisible(true);
                DurableWakeLockDetectionEngine.detect();
             }if(Jbc_IDP.isSelected()){
                listBox.add(Jbc_IDP);
                numOfBoxSelected++;
                Uchoose=false;
                Constants.SLIST.add(Constants.A_INEFFICIENT_DATA_STRUCTURE);
                detectionLoader.setVisible(true);
                InefficientDFormatParserDetectionEngine.detect();
            }if(Jbc_IDS.isSelected()){
                listBox.add(Jbc_IDS);
                numOfBoxSelected++;
                Uchoose=false;
                Constants.SLIST.add(Constants.A_INEFFICIENT_DATA_STRUCTURE);
                detectionLoader.setVisible(true);
                InefficientDSDetectionEngine.detect();
            }if(Jbc_ISG.isSelected()){
                listBox.add(Jbc_ISG);
                numOfBoxSelected++;
                Uchoose=false;
                Constants.SLIST.add(Constants.A_INTERNAL_GETTER_SETTER);
                detectionLoader.setVisible(true);
                InternalSetGetDetectionEngine.detect();
            }if(Jbc_VC.isSelected()){
                listBox.add(Jbc_VC);
                numOfBoxSelected++;
                Uchoose=false;
                Constants.SLIST.add(Constants.A_VIEWS_IN_COLLECTION);
                detectionLoader.setVisible(true);
                ViewsCollectionDetectionEngine.detect();
            }if(Jbc_LT.isSelected()){
                listBox.add(Jbc_LT);
                numOfBoxSelected++;
                Uchoose=false;
                Constants.SLIST.add(Constants.A_LEAKING_THREAD);
                detectionLoader.setVisible(true);
                LeakingThreadDetectionEngine.detect();
            }if(Jbc_PD.isSelected()){
                listBox.add(Jbc_PD);
                numOfBoxSelected++;
                Uchoose=false;
                Constants.SLIST.add(Constants.A_PUBLIC_DATA);
                detectionLoader.setVisible(true);
                PublicDataDetectionEngine.detect();
            }if(Jbc_RAM.isSelected()){
                listBox.add(Jbc_RAM);
                numOfBoxSelected++;
                Uchoose=false;
                Constants.SLIST.add(Constants.A_RIGID_ALARM_MANAGER);
                detectionLoader.setVisible(true);
                RigidAlarmManagerDetectionEngine.detect();
            }if(Jbc_SB.isSelected()){
                listBox.add(Jbc_SB);
                numOfBoxSelected++;
                Uchoose=false;
                Constants.SLIST.add(Constants.A_STATIC_BITMAP);
                detectionLoader.setVisible(true);
                StaticBitmapDetectionEngine.detect();
            }if(Jbc_SC.isSelected()){
                listBox.add(Jbc_SC);
                numOfBoxSelected++;
                Uchoose=false;
                Constants.SLIST.add(Constants.A_STATIC_CONTEXT);
                detectionLoader.setVisible(true);
                StaticContextDetectionEngine.detect();
            }if(Jbc_SV.isSelected()){
                listBox.add(Jbc_SV);
                numOfBoxSelected++;
                Uchoose=false;
                Constants.SLIST.add(Constants.A_STATIC_VIEW);
                detectionLoader.setVisible(true);
                StaticViewDetectionEngine.detect();
            }if(Jbc_UC.isSelected()){
                listBox.add(Jbc_UC);
                numOfBoxSelected++;
                Uchoose=false;
                Constants.SLIST.add(Constants.A_UNCLOSED_CLOSEABLE);
                detectionLoader.setVisible(true);
                UnclosedCloseableDetectionEngine.detect();
            }
            if(Uchoose){
                JOptionPane.showMessageDialog(new JFrame(), "Please Choose an Anti-Pattern for detection.", "INFO",
                        JOptionPane.INFORMATION_MESSAGE);
            }

            if(Jcb_SFL.isSelected() && Jcb_MIM.isSelected() && numOfBoxSelected == 2){
                CreateFile.createTwoSmell2(Constants.A_MEMBER_IGNORING_METHOD,Constants.A_SLOW_FOR_LOOP,"SFLandMIM");
//                CreateFile.createNothing();
                CreateFile.createNo(Constants.A_MEMBER_IGNORING_METHOD,Constants.A_SLOW_FOR_LOOP,"SFLandMIM");
                System.out.println("NONONONONONONONONONONONONONNONONNONOONONONNONONONONONNONONONONONNONONONONONNONONONONONNONONONONONNONONONONONNONONONONONNONONONONONNONONONONONNONONONONONNONONONONONNONONONONONNONONONONONONON");
//                HashMap<String, HashMap<String, String>> no = Constants.NO;
//                System.out.println(no.get(Constants.A_MEMBER_IGNORING_METHOD).size());
//                System.out.println(no.get(Constants.A_SLOW_FOR_LOOP).size());
                Constants.NO.forEach((a,b) -> System.out.println(a + "-->" + b));
                System.out.println("NONONONONONONONONONONONONONNONONONONONONNONONONONONNONONONONONNONONONONONNONONONONONNONNONOONONONONONONONONONONNONONONONONNONONONONONNONONONONONNONONONONONN");
            }

//            if(Jcb_LM.isSelected() && Jcb_MIM.isSelected() && numOfBoxSelected == 2){
//                CreateFile.createTwoSmell2(Constants.A_MEMBER_IGNORING_METHOD,Constants.A_LOW_MEMORY,"LMandMIM");
//                CreateFile.createNothing();
//            }

            AnalyseClass.xchange();
            AnalyseClass.Analyse();
            System.out.println("newoxtnewnewnewnewnenwenwwneenwnenewnen");




            new DataWin();


//            switch (selectedApAndroid) {
//                case LEAKING_INNER_CLASS://1
//                    detectionLoader.setVisible(true);
//                    LeakingInnerClassDetectionEngine.detect();
//                    break;
//                case MEMBER_IGNORING_METHOD://2
//                    detectionLoader.setVisible(true);
//                    MIMDetectionEngine.detect();
//                    break;
//                case LEAKING_THREAD://3
//                    detectionLoader.setVisible(true);
//                    LeakingThreadDetectionEngine.detect();
//                    break;
//                case INTERNAL_GETTER_SETTER://4
//                    detectionLoader.setVisible(true);
//                    InternalSetGetDetectionEngine.detect();
//                    break;
//                case INEFFICIENT_DATA_STRUCTURE://5
//                    detectionLoader.setVisible(true);
//                    InefficientDSDetectionEngine.detect();
//                    break;
//                case INEFFICIENT_DATA_FORMAT_PARSER://6
//                    detectionLoader.setVisible(true);
//                    InefficientDFormatParserDetectionEngine.detect();
//                    break;
//                case SLOW_FOR_LOOP://7
//                    detectionLoader.setVisible(true);
//                    SlowForLoopDetectionEngine.detect();
//                    break;
//                case PUBLIC_DATA://8
//                    detectionLoader.setVisible(true);
//                    PublicDataDetectionEngine.detect();
//                    break;
//                case LOW_MEMORY://9                //4 splide
//                    detectionLoader.setVisible(true);
//                    LowMemoryDetectionEngine.detect();
//                    break;
//                case DURABLE_WAKE_LOCK://10
//                    detectionLoader.setVisible(true);
//                    DurableWakeLockDetectionEngine.detect();
//                    break;
//                case RIGID_ALARM_MANAGER://11
//                    detectionLoader.setVisible(true);
//                    RigidAlarmManagerDetectionEngine.detect();
//                    break;
//                case UNCLOSED_CLOSEABLE://12
//                    detectionLoader.setVisible(true);
//                    UnclosedCloseableDetectionEngine.detect();
//                    break;
//                case STATIC_CONTEXT://13
//                    detectionLoader.setVisible(true);
//                    StaticContextDetectionEngine.detect();
//                    break;
//                case STATIC_VIEW://14
//                    detectionLoader.setVisible(true);
//                    StaticViewDetectionEngine.detect();
//                    break;
//                case STATIC_BITMAP://15
//                    detectionLoader.setVisible(true);
//                    StaticBitmapDetectionEngine.detect();
//                    break;
//                case VIEWS_IN_COLLECTION://16
//                    detectionLoader.setVisible(true);
//                    ViewsCollectionDetectionEngine.detect();
//                    break;
//                case COLLECTION_BITMAPS://17
//                    detectionLoader.setVisible(true);
//                    BitmapsCollectionDetectionEngine.detect();
//                    break;
//                case DROPPED_DATA://18
//                    detectionLoader.setVisible(true);
//                    DroppedDataDetectionEngine.detect();
//                    break;
//                case DEBUGGABLE_RELEASE:
//                    ASD.clearConsole();
//                    writeMessage("Class: " + LegacySystem.getInstance().getDebuggable());
//                    ASD.writeMessage("Total: " + LegacySystem.getInstance().getDebuggable());
////                            }
//                    break;
//                case CONFIG_CHANGES:
//                    ASD.clearConsole();
//                    ASD.writeMessage("Total: " + LegacySystem.getInstance().getConfigChanges());
//                    break;
//                case NESTED_LAYOUT:
//                    ASD.clearConsole();
//                    ASD.writeMessage("Total: " + LegacySystem.getInstance().getNestedLayouts());
//                    break;
//                case NOT_DESCRIPTIVE_UI:
//                    ASD.clearConsole();
//                    ASD.writeMessage("Total: " + LegacySystem.getInstance().getNotDescriptiveUi());
//                    break;
//                case UNTOUCHABLE:
//                    ASD.clearConsole();
//                    ASD.writeMessage("Total: " + LegacySystem.getInstance().getUntouchables());
//                    break;
//                case UNCONTROLLED_FOCUS_ORDER:
//                    ASD.clearConsole();
//                    ASD.writeMessage("Total: " + LegacySystem.getInstance().getUncontrolledFocusOrder());
//                    break;
//                case OVERDRAWN_PIXEL:
//                    ASD.clearConsole();
//                    ASD.writeMessage("Total: " + LegacySystem.getInstance().getOverDrawnPixel());
//                    break;
//                case NONE:
//                    JOptionPane.showMessageDialog(new JFrame(), "Please Choose an Anti-Pattern for detection.", "INFO",
////                            JOptionPane.INFORMATION_MESSAGE);
////                    break;
//            }
//            }
        });


        btnReset.addActionListener(arg0 -> {
            Constants.SLIST.clear();
            Constants.HMAP.clear();
            Constants.SMELL.clear();
            Constants.Nothing.clear();
            numOfBoxSelected = 0;

            CreateFile.reset();


            listBox.forEach(a -> a.setSelected(false));
            listBox.clear();

            parsingLoader.setVisible(false);
            projectSrcFolder = null;
            btnDetect.setEnabled(false);
            parsingStage = ParsingStages.NONE;
            buttonGroup.clearSelection();
            browseProjectPicker.rest();
            LegacySystem.getInstance().reset();
            clearConsole();
        });



    }
    static void setMyStyle(){
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        }catch(Exception e) {
            System.out.println(e);
        }
    }
    static void setPanel(JPanel panel){
        panel.setBackground(null);
        panel.setOpaque(false);
    }


    private static void findRelations() {
        for (LegacyClass legacyClass : LegacySystem.getInstance().getAllClasses()) {
//            if (!legacyClass.getClassOrInterfaceDeclaration().isInterface()) {
            legacyClass.findInherits();
            legacyClass.findUses();
            legacyClass.findCalls();
            legacyClass.findCreates();
            legacyClass.findHas();
            legacyClass.findReferences();
        }
        System.out.println("Finding Relations Done.");

        MyDpvdXmlVisitor.detectFromXmlFiles(new File(projectSrcFolder));

    }

    private static void parse() {//3.1

        parsingLoader.setVisible(true);//

        //
        SwingWorker<Void, Void> mySwingWorker = new SwingWorker<Void, Void>() {
            @Override
            protected Void doInBackground() throws Exception {//the  key

                MyDpvdVisitor.listClasses(new File(projectSrcFolder));//3.1 parser all class
                System.out.println("Parsing Done. ");
                System.out.println("LegacySystem Total calsses : " + LegacySystem.getInstance().getAllClasses().size());
                System.out.println("Finding Relations");
                findRelations();

                return null;
            }
        };

        //监听解析完成
        mySwingWorker.addPropertyChangeListener(new PropertyChangeListener() {
            @Override
            public void propertyChange(PropertyChangeEvent evt) {
                if (evt.getPropertyName().equals("state")) {
                    if (evt.getNewValue() == SwingWorker.StateValue.DONE) {
                        System.out.println("Parsing and relations Done. ");
                        parsingLoader.setIcon(new ImageIcon("resources/images/tick3.jpg"));
                        parsingStage = ParsingStages.DONE;//3.3  finish
                        btnDetect.setEnabled(true);//3.4  -> 4
                    }
                }
            }
        });
        mySwingWorker.execute();
    }

    public static void writeMessage(String msg) {
        jtaConsole.append("\n");
        jtaConsole.append(msg);
    }

    public static void detectionDone() {
        new Timer().schedule(
                new TimerTask() {
                    @Override
                    public void run() {
                        // your code here
                        detectionLoader.setVisible(false);
                    }
                },
                2000
        );
    }

    public static void clearConsole() {
        jtaConsole.setText("");
    }

    /*用来设置j的布局的

     */
    public static void setContainL(JComponent j,JComponent p){
        Dimension jSize = j.getPreferredSize();
        j.setBounds(Constants.FRAME_WITH/2 - jSize.width / 2,p.getY()+p.getHeight() , jSize.width, jSize.height);
    }

    public enum ParsingStages {
        NONE, PARSING, DONE
    }

}
