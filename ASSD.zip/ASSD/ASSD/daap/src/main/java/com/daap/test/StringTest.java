package com.daap.test;

import com.daap.util.Constants;

import java.util.HashMap;

public class StringTest {
    public static void main(String[] args) {
        StringBuffer sb = new StringBuffer("/app/src/main/java/a2dp/OXT/Vol/EditDevice.java");
        sb.delete(sb.indexOf("/app/src/main/java/"), sb.indexOf("/app/src/main/java/") + 19);
        //删除是找到指定子串的第一个位置，再到你指定的位置
        sb.delete(sb.lastIndexOf(".java"),sb.lastIndexOf(".java")+5);
        String s=sb.toString().replace("/",".");
        System.out.println(s);

//        System.out.println(s);
//        Constants.HMAP.put("fda",new HashMap<>());
////        Constants.HMAP.get("fda").put("as",1);
//        Constants.HMAP.put("asff",new HashMap<>());
////        Constants.HMAP.get("asff").put("ad",2);
//        Object bf[] =  Constants.HMAP.keySet().toArray();
//        for(Object sxx : bf)
//            System.out.println((String)sxx);
        String sxxx="/app/src/androidTest/java/de/rampro/activitydiary/MainActivityInstrumentedTest.java";
        if(sxxx.contains("/app/src/test/java/")||sxxx.contains("/app/src/androidTest/java/")){
            System.out.println("yes?");
        }
    }
}
