package com.daap.engine.anti_patterns.mobile;

import com.daap.model.DetectedInstance;
import com.daap.model.LegacyClass;
import com.daap.model.LegacySystem;
import com.daap.ui.ASD;
import com.daap.util.CreateFile;
import com.daap.util.Constants;
import com.daap.util.Helper;
import com.daap.util.ResultDocument;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.NodeList;
import com.github.javaparser.ast.expr.Expression;
import com.github.javaparser.ast.stmt.ForStmt;
import com.github.javaparser.ast.stmt.ForeachStmt;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;

import javax.xml.transform.sax.SAXTransformerFactory;
import java.util.*;

/**
 * Created by Azhar on 9/21/2017.
 */
public class SlowForLoopDetectionEngine {

    private static int total = 0;
    private static boolean isSFL = false;
    private static int ISSFL = 0;
    private static int NOTSFL = 0;
    public static String smell = "SFL";


    public static void reset(){
        total = 0;
        isSFL = false;
        ISSFL = 0;
        NOTSFL = 0;
    }


    public static void detect() {
        reset();
//        XWPFDocument doc;
//        XWPFTable table;
//        doc = new XWPFDocument();
//        table = doc.createTable();
//        table.getRow(0).getCell(0).setText("Sr. No");
//        table.getRow(0).createCell().setText("Class");
////        table.getRow(0).createCell().setText("Method");
//        table.getRow(0).createCell().setText("Path");

        total = 0;
//        ASD.clearConsole();
        ASD.writeMessage("Slow For Loop:\n");
        ResultDocument resultDocument = new ResultDocument(Constants.A_SLOW_FOR_LOOP);
        ArrayList<DetectedInstance> detectedInstances = new ArrayList<>();
        System.out.println("======================STARTED-------------------");

        for (LegacyClass legacyClass : LegacySystem.getInstance().getAllClasses()) {

            ArrayList<ForStmt> forStmts = new ArrayList<>();
            legacyClass.getClassOrInterfaceDeclaration().accept(new VoidVisitorAdapter<Object>() {



                @Override
                public void visit(ForeachStmt foreachStmt, Object arg) {
                    super.visit(foreachStmt, arg);
                    isSFL = false;
                    try {
                        CreateFile.createFile(foreachStmt.clone().toString(),smell,NOTSFL+"",isSFL);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    NOTSFL++;

                    Constants.Nothing.add(foreachStmt.clone().toString());

                    Constants.setNo(Constants.A_SLOW_FOR_LOOP,legacyClass.getName(),foreachStmt.clone().toString());
                }

                @Override
                public void visit(ForStmt forStmt, Object javaParserFacade) {
                    super.visit(forStmt, javaParserFacade);
                    if(judge(forStmt)){

                        isSFL = true;
                        try {
                            CreateFile.createFile(forStmt.clone().toString(),smell,ISSFL+"",isSFL);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        ISSFL++;

                        System.out.println(forStmt);

                        forStmts.add(forStmt);
                        total++;
    //                    ASD.writeMessage("Class: " + legacyClass.getName());
                        ASD.writeMessage("Class Name: " + legacyClass.getName()//ͨ����Ѱ��
                                + "\nPath: " + legacyClass.getPath() + "\n"
                        );

                        //����1
    //                    Constants.CNAME.add(legacyClass.getName());

    //                    Constants.setHmap(legacyClass.getName(),Constants.A_SLOW_FOR_LOOP);

                        Constants.setHmap(legacyClass.getPath(),Constants.A_SLOW_FOR_LOOP);

                        Constants.setSmell(Constants.A_SLOW_FOR_LOOP,legacyClass.getPath(),forStmt.clone().toString());


    //                    Helper.writeDoc(table, legacyClass, total);
    //                    Constants.HMAPI["A_SLOW_FOR_LOOP"]
                        System.out.println("legacyClass: " + legacyClass.getName() + " has traditional slower for loops");
                        boolean exists = true;
                        for (DetectedInstance detectedInstance: detectedInstances){
                            if (detectedInstance.getName().equals(legacyClass.getName())){
                                detectedInstance.increment();
                                exists = false;
                                break;
                            }
                        }
                        if (exists){
                            detectedInstances.add(new DetectedInstance(legacyClass.getName(), legacyClass.getPath(), 1));
                        }


                    }else{

                        isSFL = false;
                        try {
                            CreateFile.createFile(forStmt.clone().toString(),smell,NOTSFL+"",isSFL);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        NOTSFL++;

                        Constants.Nothing.add(forStmts.clone().toString());

                        Constants.setNo(Constants.A_SLOW_FOR_LOOP,legacyClass.getName(),forStmt.clone().toString());

                    }
                }
            }, null);

//            if (!forStmts.isEmpty()) {
//                total++;
//                ASD.writeMessage("Class: " + legacyClass.getName());
//                System.out.println("legacyClass: " + legacyClass.getName() + " has traditional slower for loops");
//            }
        }

        System.out.println("total: " + total);
        ASD.writeMessage("Total: "+total);
        ASD.detectionDone();
//        Helper.writeFile(doc, "SlowForLoop");
        System.out.println("======================FINISHED-------------------");
        int srNo = 1;
        for (DetectedInstance detectedInstance : detectedInstances) {
            Helper.writeDoc(resultDocument, detectedInstance, srNo++);
        }
        Helper.writeFile(resultDocument);



    }

    /**
     *  �ж������ͨforѭ�����ܲ��ܸĳ�for-each������ܣ��ǲ������slf����ζ����Ȼ�Ͳ���
     *
     * @param forStmt
     * @return
     */
    public static boolean judge(ForStmt forStmt){

        //������������򼯺ϣ������������ı�����ģ����±�=0 ������ length ������ǴӺ���ǰ��Ҳ�㲻��
        //�±���������һ��һ������Ҳ����++�����ұ����0��ʼ
        //����������� һ���Ǵ�0��<= length - 1, һ���ǵ� < length,�����-������Ҳ����

        if(forStmt.getCompare().isPresent()){
            //��ȡ����������򼯺�  �Լ� �±�
            List<Node> childNodes = forStmt.getCompare().get().getChildNodes();
            Node value = null,arr = null;
            if(childNodes.size() == 2){
                value = childNodes.get(0);  // �±����
                arr = childNodes.get(1);   // ����򼯺�, ��������Ҳ����һ���������� ����j����Ҳ�㲻�аɣ���Ϊ�޷��ж���������Ƕ��
            }else{
                return false;   //����ж������������� �ǿ��ܾ��и�������򼯺ϲ���ص�
            }

            //�ж��±�����0��ʼ ��Ϊ ++
            NodeList<Expression> initialization = forStmt.getInitialization();
            NodeList<Expression> update = forStmt.getUpdate();  //�����һ��++��һ��Ԫ��
            if(initialization.size() > 0) {
                if (!initialization.get(0).toString().replaceAll(" ", "").contains(value + "=0")) {
                    return false; //����������±����=0   ֮����ֻget(0)������Ϊ����������ȫ��������һ���������0
                }
            }else{
                return false;
            }

            boolean flag_update = false;
            for(int i = 0; i < update.size(); i++){
                if(update.get(i).toString().equals(value+"++") || update.get(i).toString().equals("++"+value)){
                    flag_update = true;
                    break;
                }
            }
            if(!flag_update){
                return false;
            }
            //---------------------------------

            //�ж�ѭ���жϵı���Ϊ <= length - 1 ���� < length, ����������
            String arr_list = (arr.toString().replaceAll(" ",""));
            String compare = forStmt.getCompare().get().toString().replaceAll(" ","");
            if(arr_list.contains("-1")){
                if(!compare.contains("<=")){
                    return false;
                }
            }else{ //������ -1������û��length - 1������ֻҪ <
                //��������� -��������Ҳ����
                if(arr_list.contains("-")){   //��Ȼû��-1���ǾͲ�Ӧ���м��ţ�������Ǽ�ȥ��������
                    return false;
                }

                if(!compare.contains("<")){
                    return false;
                }
            }

            String set = "";
            //--------------------------------
            //���ѭ�����д��� .remove  .add  ,���ϵĳ��Ⱦ���size()
            String body = forStmt.getBody().toString();
            if(arr.toString().contains(".size()")){
                String list = arr.toString().substring(0,arr.toString().indexOf(".size()"));
                set = arr.toString().substring(0,arr.toString().indexOf(".size()"));
                String compare_add = list+".add";
                String compare_put = list+".put";
                String compare_remove = list+".remove";
                String compare_clear = list+".clear";
                if(body.contains(compare_add) || body.contains(compare_put) || body.contains(compare_remove) || body.contains(compare_clear)){
                    return false;
                }

                //����������д��ڶԼ��ϻ�����ĸ�ֵ���� ����/���� = xxx
                //�˴�Ҳ��Ҫ��ѭ�������ж�ȫ����

            }else{
                if(!arr.toString().contains(".length")){
                    return false;
                }
                set = arr.toString().substring(0,arr.toString().indexOf(".length"));
            }

            //�����Դ���ʹ���±�charAt
            if(body.contains(set+".charAt")){
                return false;
            }

            //�����Դ���return i;   ��ʹ�����±�
            if(!judge_return_index(new StringBuilder(body),"return",value.toString())){
                return false;
            }

            //----------------------------------------
            //����������д��ڶԼ��ϻ�����ĸ�ֵ���� ����/���� = xxx
            //�˷������������ if ( �±�һ�����������µ����Ѱ��indexOf����������indexOf(=),���Ƿ��и�ֵ����
            StringBuilder body3 = new StringBuilder(body);
            int count3 = 0;
            while (count3 < body3.length()){
                String body3_string = body3.toString();
                if(body3_string.contains(set) && body3_string.contains("=")){
//                         && body.indexOf(list) < body.indexOf("=")
                    int index_list = body3_string.indexOf(set,count3);
                    if(index_list + 1 > body3_string.length() - 1){
                        break;
                    }
                    int index_deng = body3_string.indexOf("=",index_list + 1);
                    if(index_deng != -1){
                        if(index_deng - index_list <= set.length() + 5){
                            //��ֹ����
                            if(judge_frBe(index_list,set.toString().length(),body3_string)){
                                return false;
                            }
                        }
                    }
                    count3 = index_list + 2;
                    if(count3 > body3_string.length() - 1){
                        break;
                    }
                    body3 = new StringBuilder(body3_string.substring(count3));
                    count3 = 0;
                }else{
                    break;
                }
            }

//            List<Character> judge_value = new ArrayList<>();

            //-----------------------------------------
            //������ڶ��±��if�ж�
            StringBuilder body2 = new StringBuilder(body);
            int count = 0;
            while(count < body2.length()){
                String body2_string = body2.toString();
                if(body2_string.contains("if") && body2_string.contains(value.toString())){
                    int index_if = body2_string.indexOf("if",count);
                    if(index_if + 1 > body2_string.length() - 1){
                        break;
                    }
                    int index_value = body2_string.indexOf(value.toString(),index_if + 1);
                    if(index_value - index_if <= 6){
                        //��ֹ����
                        if(judge_frBe(index_if,2,body2_string)){
                            if(judge_frBe(index_value,value.toString().length(),body2_string)){
                                return false;
                            }
                        }
                    }
                    count = index_if + 1;
                    if(count > body2_string.length() - 1){
                        break;
                    }
                    body2 = new StringBuilder(body2_string.substring(count));
                    count = 0;
                }else{
                    break;
                }
            }

            //------------------------
            //�� = �±� �����ж�
//            judge_index(body,value.toString(),"=");
            StringBuilder body4 = new StringBuilder(body);
            int count4 = 0;
            while(count4 < body4.length()){
                String body4_string = body4.toString();
                if(body4_string.contains("=") && body4_string.contains(value.toString())){
                    int index_deng = body4_string.indexOf("=",count4);
                    if(index_deng + 1 > body4_string.length() - 1){
                        break;
                    }
                    int index_value = body4_string.indexOf(value.toString(),index_deng + 1);

                    if(index_value - index_deng <= 3){
                        //��ֹ���� itent = ������� n���±꣬��itent���ǣ���һ���㶨λ��n��
                        if(judge_frBe(index_value,value.toString().length(),body4_string)){
                            return false;
                        }
//                        char front = ' ';
//                        char behind = ' ';
//                        if(index_value - 1 >= 0){
//                            front = body4_string.charAt(index_value - 1);
//                        }
//                        if(index_value + value.toString().length() < body4_string.length()){
//                            behind = body4_string.charAt(index_value + value.toString().length());
//                        }
//                        if(!((front >= 'a' && front <= 'z') || (front >= 'A' && front <= 'Z'))){
//                            if(!(behind >= 'a' && behind <= 'z') || (behind >= 'A' && behind <= 'Z')){
//                                return false;
//                            }
//                        }
                    }
                    count4 = index_deng + 1;

                    if(count4 > body4_string.length() - 1){
                        break;
                    }
                    body4 = new StringBuilder(body4_string.substring(count4));
                    count4 = 0;
                }else{
                    break;
                }
            }

            //�� �±� = �����ж�
//            judge_index(body,"=",value.toString());
            StringBuilder body5 = new StringBuilder(body);
            int count5 = 0;
            while(count5 < body5.length()){
                String body5_string = body5.toString();
                if(body5_string.contains("=") && body5_string.contains(value.toString())){
                    int index_value = body5_string.indexOf(value.toString(),count5);
                    if(index_value + 1 > body5_string.length() - 1){
                        break;
                    }
                    int index_deng = body5_string.indexOf("=",index_value + 1);
                    if(index_deng - index_value <= 3) {
                        if(judge_frBe(index_value,value.toString().length(),body5_string)){
                            return false;
                        }
//                        char front = ' ';
//                        char behind = ' ';
//                        if(index_value - 1 > 0){
//                            front = body5_string.charAt(index_value - 1);
//                        }
//                        if(index_value + value.toString().length() < body5_string.length()){
//                            behind = body5_string.charAt(index_value + value.toString().length());
//                        }
//                        if (!((front >= 'a' && front <= 'z') || (front >= 'A' && front <= 'Z'))) {
//                            if (!(behind >= 'a' && behind <= 'z') || (behind >= 'A' && behind <= 'Z')) {
//                                return false;
//                            }
//                        }
                    }
                    count5 = index_value + 1;

                    if(count5 > body5_string.length() - 1){
                        break;
                    }
                    body5 = new StringBuilder(body5_string.substring(count5));
                    count5 = 0;
                }else{
                    break;
                }
            }

            //���±걻�Ǳ���ѭ������������򼯺�ʹ�ã�Ҳ�ǲ��е�
            StringBuilder body6 = new StringBuilder(body);
            int count6 = 0;
            while(count6 < body6.length()){
                String body6_string = body6.toString();
                if(body6_string.contains("["+value.toString()+"]") ){
                    int index_value = body6_string.indexOf("["+ value +"]",count6);

                    if(index_value - set.length() > 0){//��ֹ�±��ܳ�������Χ
                        if(!body6_string.substring(index_value - set.length(),index_value).equals(set)){
                            return false;
                        }
                    }else{
                        return false;
                    }
                    count6 = index_value + 2;

                    if(count6 > body6_string.length() - 1){
                        break;
                    }
                    body6 = new StringBuilder(body6_string.substring(count6));
                    count6 = 0;
                }else{
                    break;
                }
            }



//            for(int index = 0; index < body2.length(); index++){
//                if(body2.contains("if") && body.contains(value.toString())){
//                    if(body.indexOf("if") - body.indexOf(value.toString()) <= 3){
//                        return false;
//                    }
//                }
//
//            }

//            if(body.contains("continue")){
//                return false;
//            }




        }else{
            return false;
        }

        return true;
    }

    /*
        ���������������  ��Ҫ�жϵ���ǰ��ı���re  �ں���ı���index
        ���ã��ж��ڷ��������Ƿ����  re index
        ���粻���Դ��� return ѭ���±�
        ������        if(ѭ���±�)
        ������        = ѭ���±�
        ������        ѭ���±� =
     */
    public static boolean judge_return_index(StringBuilder sb,String re,String index){
        int count = 0;
        while(count < sb.length()){
            String body = sb.toString();
            if(body.contains(re) && body.contains(index)){
                int index_re = body.indexOf(re,count);
                //�ж���������������� ������������ ���� areturnb ����Ҳ���ҵ�return
//                char front = body.charAt(index_re - 1);
//                char behind = body.charAt(index_re + re.length());
//                if(!(front >= 'a' && front <= 'z')|| (front >= 'A' && front <= 'Z')){
//                    if(!(behind >= 'a' && behind <= 'z') || (behind >= 'A' && behind <= 'Z')){
//                        int index_in = body.indexOf(index,index_re + re.length());
//                    }
//                }
                if(judge_frBe(index_re,re.length(),body)){
                    int index_in = body.indexOf(index,index_re + re.length());
                    if(judge_frBe(index_in,index.length(),body)){
                        if(index_in - index_re < re.length() + 3){
                            return false;
                        }
                    }
                }
                count = index_re + 1;
                if(count > sb.length() - 1){
                    break;
                }
                sb = new StringBuilder(sb.substring(count));
                count = 0;
            }else{
                break;
            }
        }
        return true;
    }

    /**
     * ��������������Ҫ�жϵ�ֵ����body�е��±꣬�ж�ֵ�ĳ��ȣ�body
     *       ���ã��ж��ҵ��ĸ�ֵ�Ƿ��������ĸ�ֵ��������i���������ҵ��� aib
     * @param value_index  �±�
     * @param value_length  ����
     * @param body
     * @return
     */
    public static boolean judge_frBe(int value_index,int value_length,String body){
        if(value_index - 1 < 0 || value_index + value_length > body.length() - 1){
            return true;
        }
        char front = body.charAt(value_index - 1);
        char behind = body.charAt(value_index + value_length);
        if(!(front >= 'a' && front <= 'z')|| (front >= 'A' && front <= 'Z')){
            if(!(behind >= 'a' && behind <= 'z') || (behind >= 'A' && behind <= 'Z')){
                return true;
            }
        }
        return false;
    }

//    //             �� = �±�   �� �±� =            index            =
//    public static boolean judge_index(String body,String value1,String value2){
//        StringBuilder body4 = new StringBuilder(body);
//        int count4 = 0;
//        while(count4 < body4.length()){
//            String body4_string = body4.toString();
//            if(body4_string.contains(value2) && body4_string.contains(value1)){
//                int index_deng = body4_string.indexOf(value2,count4);
//                if(index_deng + 1 > body4_string.length() - 1){
//                    break;
//                }
//                int index_value = body4_string.indexOf(value1,index_deng + 1);
//
//                if(index_value - index_deng <= 3){
//                    //��ֹ���� itent = ������� n���±꣬��itent���ǣ���һ���㶨λ��n��
//                    char front = ' ';
//                    char behind = ' ';
//                    if(index_value - 1 >= 0){
//                        front = body4_string.charAt(index_value - 1);
//                    }
//                    if(index_value + value1.length() < body4_string.length()){
//                        behind = body4_string.charAt(index_value + value1.length());
//                    }
//                    if(!((front >= 'a' && front <= 'z') || (front >= 'A' && front <= 'Z'))){
//                        if(!(behind >= 'a' && behind <= 'z') || (behind >= 'A' && behind <= 'Z')){
//                            return false;
//                        }
//                    }
//                }
//                count4 = index_deng + 1;
//
//                if(count4 > body4_string.length() - 1){
//                    break;
//                }
//                body4 = new StringBuilder(body4_string.substring(count4));
//                count4 = 0;
//            }else{
//                break;
//            }
//        }
//        return true;
//    }

}
