package com.daap.callbacks;

public interface OnConsoleWriter {

    void writeMessage(String msg);
    void clearConsole();
}
